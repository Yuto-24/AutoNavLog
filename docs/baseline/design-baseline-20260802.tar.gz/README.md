# AutoNavLog

AutoNavLogは、航空大学校 宮崎課程 NAV2の航法LOG作成を支援する、SR22 G6向けの
**地上準備専用**ツールです。計算結果とA4横の転記補助表は、運航資料、完成帳票、
別添8-1原本ではありません。利用者が根拠と警告を確認し、公式様式へ手書きで転記する
ための非公式補助です。航空大学校の公式様式・計算規則への準拠は主張しません。

## 現在の検証状態

アプリケーション、計算Policy、MSM連携、保存、KML/KMZ取込、Colab UI、テスト基盤を
実装しています。`data/performance`にはSR22 G6 POH P/N 13772-006 Reissue Aの上昇
19行・巡航159行を収録し、原典PDFからの再抽出と全行差分比較を完了しています。上昇表の
ISA温度および標準より10℃高いごとの10%増加もmanifestで明示したPolicyとして適用します。

これは対象機固有の日本承認AFM/POH・Supplementとの適用確認や、校内Golden NAV2 LOGとの
一致を意味しません。これらと気象QNH、丸め、SEA、LOSS等の未確認事項が残るため、
結果を航空大学校の承認済みNAV LOGまたは運航資料とは表示しません。
SEAは地形・障害物から自動算出せず、利用者が全Legへ手入力します。未入力、または
計画高度が入力SEAを下回る間は`MANUAL_INPUT_REQUIRED`として転記不可にします。

## 開発

Python 3.12を主対象とし、3.10〜3.12をサポートします。MSM実連携は
`jma-msm-wind` v0.2.1へ固定しています。

```bash
uv venv --python 3.12
source .venv/bin/activate
uv pip install -e ".[test]"
pytest
ruff check .
mypy src/autonavlog
python scripts/validate_performance_data.py data/performance
python scripts/validate_notebook.py notebooks/AutoNavLog.ipynb
python scripts/export_schemas.py --check
```

MSM契約試験やColabリリースでは、Privateリポジトリから作成した
`jma_msm_wind-0.2.1` wheelをAutoNavLog wheelと同時にインストールします。

## Colab配布

### Colab操作プレビュー

`notebooks/AutoNavLog_Colab_Preview.ipynb`は、地上準備の操作確認と非公式転記補助だけを
目的とします。空港・SR22 G6性能データ、AutoNavLog wheel、固定版
`jma-msm-wind==0.2.1` wheelを、内部manifestで全fileのsize/SHA-256を検査する単一ZIPへ
まとめて使用します。

```bash
python scripts/build_colab_preview_bundle.py \
  dist/autonavlog-0.1.0-py3-none-any.whl \
  /path/to/jma_msm_wind-0.2.1-py3-none-any.whl \
  dist/autonavlog-colab-preview-0.1.0.zip
```

ZIPをColab VMの`/content`、またはGoogle Driveの`MyDrive`直下へ配置してNotebookを
実行します。上空風・気温はMSM予報値です。QNHは最新METARの観測値であって予報では
ありません。METAR観測時刻が取得時点またはETDから2時間を超えて離れる場合は自動採用
せず、利用者が適切なQNHを手入力します。このプレビューはPzs地形データおよび
MSM推定QNHを使用しません。

### 旧Pzs release bundle（使用停止中）

次の旧経路は、PzsのLambert格子を`jma-msm-wind==0.2.1`が分離した緯度・経度軸として
扱う問題と、Pzsの取得・再配布条件が未解決のため、現在は配布・実行しません。
`release-to-drive` workflow、`notebooks/AutoNavLog.ipynb`、Pzs acceptance gateは
将来の修正用に残している隔離済み経路です。現時点のColab配布には、上記の
`AutoNavLog_Colab_Preview.ipynb`とPzsを含まないpreview ZIPだけを使用します。

1. GitHub Actionsの`release-to-drive`を手動実行します。
2. CIがAutoNavLogとMSMのwheel、Notebook、性能・空港データ、Pzs地形キャッシュ、
   SHA-256付き`release-manifest.json`を共有Google Driveへ配置します。
3. 利用者は配布Notebookを自分のDriveへコピーし、「すべて実行」を押します。
4. Notebookは指定版wheelだけをインストールし、新版がある場合は通知だけを表示します。

必要なActions secrets:

| Secret | 内容 |
|---|---|
| `MSM_REPO_TOKEN` | `Yuto-24/jma-msm-wind-kyushu`のread権限 |
| `GDRIVE_SERVICE_ACCOUNT_JSON` | DriveへアップロードするService Account JSON |
| `GDRIVE_RELEASE_FOLDER_ID` | 共有Driveのリリース親フォルダ |
| `GDRIVE_TERRAIN_FILE_ID` | 検証済みPzs `terrain.npz` |

1 Projectを複数Notebookから同時編集しないでください。revisionが競合した場合、
AutoNavLogは既存ファイルを上書きせず`project-conflict-*.json`を保存します。

## ディレクトリ

- `src/autonavlog/domain`: Project、計算結果、Snapshot、気象契約
- `src/autonavlog/nav`: 測地線、PA、TAS/CAS、風、燃料、丸め
- `src/autonavlog/performance`: 性能CSV検証、上昇補間、巡航セル選択
- `src/autonavlog/weather`: FakeとMSM v0.2.1アダプター
- `src/autonavlog/storage`: Local/Google Drive保存とrevision管理
- `src/autonavlog/presentation`: Colab UIとA4横の非公式転記補助表
- `notebooks/AutoNavLog.ipynb`: 利用者向けの薄い起動Notebook

詳細は[アーキテクチャ](docs/architecture.md)、
[計算規則](docs/calculation_rules.md)、
[データ来歴](docs/data_provenance.md)、
[一次資料監査](docs/primary_source_audit.md)を参照してください。
