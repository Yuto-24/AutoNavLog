from __future__ import annotations

from datetime import datetime
from html import escape
from math import isclose, isfinite
from pathlib import Path
from typing import Any
from uuid import UUID
from zoneinfo import ZoneInfo

import folium
import ipywidgets as widgets
from IPython.display import display

from autonavlog.application.calculation_service import CalculationService
from autonavlog.application.project_service import ProjectService
from autonavlog.domain.calculation import CalculationOutcome
from autonavlog.domain.enums import FlightPhase, RouteNodeRole
from autonavlog.domain.project import Airport, NavSection, Project, RouteNode
from autonavlog.importers.kml import (
    KmlImportResult,
    import_kml_or_kmz,
    import_kml_text,
)
from autonavlog.nav.geodesy import geodesic_leg
from autonavlog.presentation.clearcopy import render_clearcopy_html
from autonavlog.presentation.transfer_aid import render_transfer_aid_document
from autonavlog.weather.provider import WeatherProvider

JST = ZoneInfo("Asia/Tokyo")
RouteEntry = tuple[str, float, float, str]
FT_TO_M = 0.3048


class AutoNavLogApp:
    """Thin, one-column Colab UI. All business decisions stay in services."""

    def __init__(
        self,
        project_service: ProjectService,
        calculation_service: CalculationService,
        weather_provider: WeatherProvider,
        *,
        download_directory: str | Path | None = None,
    ):
        self.project_service = project_service
        self.calculation_service = calculation_service
        self.weather_provider = weather_provider
        self.download_directory = (
            None if download_directory is None else Path(download_directory)
        )
        self.project: Project | None = None
        self.outcome: CalculationOutcome | None = None
        self.import_result: KmlImportResult | None = None
        self._imported_kml_text: str | None = None
        self._kml_altitude_note: str | None = None
        self._setting_kml_altitude = False
        self._all_leg_altitude_user_edited = False
        self.message = widgets.HTML()
        self.name = widgets.Text(description="Project")
        self.pilot = widgets.Text(description="PILOT")
        self.ship = widgets.Text(description="SHIP")
        self.flight_date = widgets.DatePicker(
            description="DATE",
            value=datetime.now(JST).date(),
        )
        self.departure_time = widgets.Text(description="ETD JST", value="09:00")
        self.departure = widgets.Text(description="FROM")
        self.destination = widgets.Text(description="TO")
        self.fuel = widgets.FloatText(description="FUEL gal", value=81.0)
        self.variation = widgets.FloatText(description="VAR E", value=8.0)
        self.create_button = widgets.Button(description="新規Project", icon="plus")
        self.create_button.on_click(self._create_project)
        self.project_id = widgets.Text(description="Project ID")
        self.load_button = widgets.Button(description="読込", icon="folder-open")
        self.load_button.on_click(self._load_project)
        self.upload = widgets.FileUpload(accept=".kml,.kmz", multiple=False)
        self.upload.observe(self._import_file, names="value")
        self.kml_text = widgets.Textarea(
            description="KML/XML",
            placeholder="Google EarthからコピーしたKML/XML全文を貼り付けてください",
            layout=widgets.Layout(width="100%", height="180px"),
        )
        self.import_text_button = widgets.Button(
            description="貼付KMLを読み込む",
            icon="paste",
        )
        self.import_text_button.on_click(self._import_text)
        self.import_summary = widgets.HTML()
        self.candidates = widgets.Select(description="候補", rows=6)
        self.map_view = widgets.HTML()
        self.add_candidate = widgets.Button(description="Routeへ追加", icon="plus")
        self.add_candidate.on_click(self._add_imported_point)
        self.shape_candidates = widgets.Select(description="形状", rows=6)
        self.shape_candidates.observe(self._shape_selected, names="value")
        self.quick_run_confirmation = widgets.Checkbox(
            description=(
                "ETD・全Leg高度を確認した。Polygonの場合は、境界・開始点・"
                "進行方向もKML記載順でRouteに使うことを確認した"
            ),
            value=False,
            disabled=True,
            indent=False,
            layout=widgets.Layout(width="100%"),
        )
        # Compatibility name for callers that used the original Polygon-only control.
        self.polygon_route_confirmation = self.quick_run_confirmation
        self.add_shape_route = widgets.Button(
            description="選択形状をRouteへ一括追加",
            icon="plus",
            disabled=True,
        )
        self.add_shape_route.on_click(self._add_imported_shape)
        self.manual_name = widgets.Text(description="名称")
        self.manual_lat = widgets.FloatText(description="緯度")
        self.manual_lon = widgets.FloatText(description="経度")
        self.add_manual = widgets.Button(description="座標を追加", icon="plus")
        self.add_manual.on_click(self._add_manual_point)
        self.route = widgets.Select(description="Route", rows=8)
        self.route.observe(self._route_selected, names="value")
        self.delete_node = widgets.Button(icon="trash", tooltip="選択点を削除")
        self.move_up = widgets.Button(icon="arrow-up", tooltip="上へ移動")
        self.move_down = widgets.Button(icon="arrow-down", tooltip="下へ移動")
        self.delete_node.on_click(self._delete_node)
        self.move_up.on_click(lambda _: self._move_node(-1))
        self.move_down.on_click(lambda _: self._move_node(1))
        self.phase = widgets.Dropdown(
            description="Phase",
            options=[item.value for item in FlightPhase],
            value=FlightPhase.CRUISE.value,
        )
        self.altitude = widgets.FloatText(description="ALT ft", value=5000)
        self.safe_altitude = widgets.Text(description="SEA ft")
        self.wind_direction = widgets.Text(description="WIND°")
        self.wind_speed = widgets.Text(description="WIND kt")
        self.temperature = widgets.Text(description="TEMP °C")
        self.tas = widgets.Text(description="TAS kt")
        self.loss_time = widgets.FloatText(description="LOSS sec", value=0)
        self.all_leg_altitude = widgets.FloatText(
            description="全Leg ALT ft",
            value=5000,
        )
        for control in (
            self.flight_date,
            self.departure_time,
            self.kml_text,
        ):
            control.observe(
                self._invalidate_quick_run_confirmation,
                names="value",
            )
        self.all_leg_altitude.observe(
            self._all_leg_altitude_changed,
            names="value",
        )
        self.apply_all_leg_altitude_button = widgets.Button(
            description="全Legへ高度を明示適用",
            icon="check",
        )
        self.apply_all_leg_altitude_button.on_click(self._apply_all_leg_altitude)
        self.manual_qnh = widgets.Text(description="QNH hPa")
        self.tgl_count = widgets.BoundedIntText(description="TGL", min=0, value=0)
        self.apply_phase = widgets.Button(description="Legへ適用", icon="check")
        self.apply_phase.on_click(self._apply_phase)
        self.run_label = widgets.HTML("<strong>Forecast Run:</strong> 未選択")
        self.calculate_button = widgets.Button(
            description="計算実行",
            icon="calculator",
            button_style="primary",
        )
        self.calculate_button.on_click(self._calculate)
        self.quick_calculate_button = widgets.Button(
            description="貼付KMLからNAV LOG計算",
            icon="calculator",
            button_style="success",
            layout=widgets.Layout(width="100%", height="48px"),
        )
        self.quick_calculate_button.on_click(self._calculate_from_pasted_kml)
        self.quick_run_status = widgets.HTML()
        self.issues = widgets.VBox()
        self.clearcopy = widgets.HTML()
        self.download_transfer_aid_button = widgets.Button(
            description="A4印刷用HTMLをダウンロード",
            icon="download",
        )
        self.download_transfer_aid_button.on_click(self._download_transfer_aid)
        self.download_transfer_aid_status = widgets.HTML()
        self.save_button = widgets.Button(description="保存", icon="save")
        self.snapshot_button = widgets.Button(description="Snapshot", icon="camera")
        self.save_button.on_click(self._save)
        self.snapshot_button.on_click(self._snapshot)

    def render(self) -> widgets.Widget:
        sections = [
            ("1. 開始・環境確認", widgets.VBox([self.message])),
            (
                "2. Projectの作成・読込",
                widgets.VBox(
                    [
                        self.name,
                        self.pilot,
                        self.ship,
                        self.flight_date,
                        self.departure_time,
                        self.departure,
                        self.destination,
                        self.create_button,
                        self.project_id,
                        self.load_button,
                    ]
                ),
            ),
            (
                "3. コース取込・編集",
                widgets.VBox(
                    [
                        widgets.HTML(
                            "<p>KML/KMZファイルを選ぶか、Google EarthのKML/XML全文を"
                            "下欄へ貼り付けてください。</p>"
                        ),
                        self.upload,
                        self.kml_text,
                        self.import_text_button,
                        self.import_summary,
                        self.map_view,
                        self.candidates,
                        self.add_candidate,
                        self.shape_candidates,
                        self.polygon_route_confirmation,
                        self.add_shape_route,
                        self.manual_name,
                        self.manual_lat,
                        self.manual_lon,
                        self.add_manual,
                        widgets.HTML(
                            "<p><strong>SEAは自動算出しません。</strong>"
                            "各LegをRoute欄で順に選び、予定経路両側3 nm内の障害物を"
                            "確認して求めたSEAを入力し、「Legへ適用」を押してください。"
                            "全LegのSEA入力後に再計算すると転記可能判定になります。</p>"
                        ),
                        self.route,
                        widgets.HBox([self.delete_node, self.move_up, self.move_down]),
                        self.phase,
                        self.altitude,
                        self.safe_altitude,
                        self.wind_direction,
                        self.wind_speed,
                        self.temperature,
                        self.tas,
                        self.loss_time,
                        self.apply_phase,
                        widgets.HTML(
                            "<p>新しく作る全Legの計画高度です。既存Legは自動上書きしません。"
                            "既存Legも変更する場合だけ明示適用を押してください。</p>"
                        ),
                        self.all_leg_altitude,
                        self.apply_all_leg_altitude_button,
                    ]
                ),
            ),
            (
                "4. 飛行計画入力",
                widgets.VBox(
                    [
                        self.fuel,
                        self.variation,
                        self.manual_qnh,
                        self.tgl_count,
                    ]
                ),
            ),
            ("5. Forecast Run選択", widgets.VBox([self.run_label])),
            (
                "6. 計算実行",
                widgets.VBox(
                    [
                        widgets.HTML(
                            "<p>Project作成、空港入力、貼付KMLのRoute化、NAV LOG計算を"
                            "まとめて実行します。</p>"
                        ),
                        self.quick_calculate_button,
                        self.quick_run_status,
                        self.calculate_button,
                    ]
                ),
            ),
            ("7. 警告・未確定項目の解消", self.issues),
            (
                "8. 転記補助表（非公式）",
                widgets.VBox(
                    [
                        self.clearcopy,
                        self.download_transfer_aid_button,
                        self.download_transfer_aid_status,
                    ]
                ),
            ),
            ("9. 保存・Snapshot作成", widgets.HBox([self.save_button, self.snapshot_button])),
        ]
        children: list[Any] = []
        for heading, body in sections:
            children.extend((widgets.HTML(f"<h3>{heading}</h3>"), body))
        root = widgets.VBox(children)
        root.add_class("autonavlog-app")
        display(  # type: ignore[no-untyped-call]
            widgets.HTML(
                """
                <style>
                .autonavlog-app {max-width:760px;margin:0 auto;gap:8px}
                .autonavlog-app .widget-label {min-width:92px}
                .autonavlog-app input,.autonavlog-app select {min-height:40px}
                </style>
                """
            )
        )
        return root

    def _create_project(self, _: Any) -> None:
        try:
            self._create_project_from_inputs()
            self._notify("Projectを作成しました。")
        except Exception as error:
            self._notify(str(error), error=True)

    def _create_project_from_inputs(self) -> Project:
        if self.flight_date.value is None:
            raise ValueError("DATEを入力してください")
        try:
            hour, minute = (
                int(value) for value in self.departure_time.value.split(":", 1)
            )
            departure_time = datetime.combine(
                self.flight_date.value,
                datetime.min.time(),
                tzinfo=JST,
            ).replace(hour=hour, minute=minute)
        except (TypeError, ValueError) as error:
            raise ValueError("ETD JSTはHH:MM形式で入力してください。") from error
        if not self.departure.value.strip() or not self.destination.value.strip():
            raise ValueError("FROMとTOを入力してください。")
        self.project = self.project_service.create(
            name=self.name.value or "NAV2",
            pilot_name=self.pilot.value,
            ship_identifier=self.ship.value,
            flight_date=self.flight_date.value,
            planned_departure_time_jst=departure_time,
            departure_airport_id=self.departure.value.strip(),
            destination_airport_id=self.destination.value.strip(),
            total_usable_fuel_gal=self.fuel.value,
            default_variation_deg_east=self.variation.value,
        )
        self.project_id.value = str(self.project.id)
        return self.project

    def _load_project(self, _: Any) -> None:
        try:
            self.project = self.project_service.repository.load(UUID(self.project_id.value))
            self._refresh_route()
            self._notify("Projectを読み込みました。")
        except Exception as error:
            self._notify(str(error), error=True)

    def _import_file(self, change: dict[str, Any]) -> None:
        try:
            if not change["new"]:
                return
            value = change["new"]
            uploaded = value[0] if isinstance(value, tuple) else next(iter(value.values()))
            raw_content = uploaded["content"]
            content = (
                raw_content.tobytes()
                if hasattr(raw_content, "tobytes")
                else bytes(raw_content)
            )
            uploaded_name = uploaded.get("name") or uploaded.get("metadata", {}).get("name")
            self._accept_import_result(
                import_kml_or_kmz(
                    content,
                    filename=uploaded_name or "upload.kml",
                )
            )
            self._imported_kml_text = None
        except Exception as error:
            self._clear_import_result()
            self._notify(str(error), error=True)

    def _import_text(self, _: Any) -> None:
        try:
            if not self.kml_text.value.strip():
                raise ValueError("KML/XMLを貼り付けてください。")
            self._accept_import_result(import_kml_text(self.kml_text.value))
            self._imported_kml_text = self.kml_text.value
        except Exception as error:
            self._clear_import_result()
            self._notify(str(error), error=True)

    def _accept_import_result(self, result: KmlImportResult) -> None:
        self.import_result = result
        self._kml_altitude_note = self._seed_altitude_from_single_polygon(result)
        self.candidates.options = [
            (
                f"{point.name} ({point.latitude_deg:.5f}, {point.longitude_deg:.5f})",
                index,
            )
            for index, point in enumerate(result.points)
        ]
        self.shape_candidates.options = [
            (f"LineString: {line.name} ({len(line.coordinates)}点)", ("line", index))
            for index, line in enumerate(result.lines)
        ] + [
            (
                f"Polygon境界: {polygon.name} "
                f"({max(0, len(polygon.outer_boundary) - 1)}点)",
                ("polygon", index),
            )
            for index, polygon in enumerate(result.polygons)
        ]
        self.polygon_route_confirmation.value = False
        self._shape_selected({"new": self.shape_candidates.value})
        summary = (
            f"<p><strong>取込結果:</strong> {len(result.points)}点、"
            f"{len(result.lines)} LineString、{len(result.polygons)} Polygon</p>"
        )
        if result.polygons:
            summary += (
                "<p style='color:#9a6700'><strong>注意:</strong> Polygonは空域・区域の"
                "境界を表す場合があり、自動的に飛行経路を意味しません。地図で確認し、"
                "Routeへ変換する場合だけ確認欄を選択してください。</p>"
            )
        if self._kml_altitude_note is not None:
            summary += (
                "<p style='color:#075985'><strong>KML高度から自動入力:</strong> "
                f"{escape(self._kml_altitude_note)}</p>"
            )
        if result.warnings:
            warning_items = "".join(
                f"<li>{escape(warning)}</li>" for warning in result.warnings
            )
            summary += f"<p><strong>取込警告:</strong></p><ul>{warning_items}</ul>"
        self.import_summary.value = summary
        self._notify(
            f"{len(result.points)}点、{len(result.lines)} LineString、"
            f"{len(result.polygons)} Polygonを読み込みました。"
        )
        self._refresh_map()

    def _clear_import_result(self) -> None:
        self.import_result = None
        self._imported_kml_text = None
        self._kml_altitude_note = None
        self.candidates.options = []
        self.shape_candidates.options = []
        self.polygon_route_confirmation.value = False
        self.polygon_route_confirmation.disabled = True
        self.add_shape_route.disabled = True
        self.import_summary.value = ""
        self._refresh_map()

    def _shape_selected(self, change: dict[str, Any]) -> None:
        selected = change.get("new")
        is_shape = (
            isinstance(selected, tuple)
            and len(selected) == 2
            and selected[0] in {"line", "polygon"}
        )
        self.add_shape_route.disabled = not is_shape
        self.quick_run_confirmation.disabled = self.import_result is None
        if change.get("old") != selected:
            self.quick_run_confirmation.value = False
        self._refresh_map()

    def _invalidate_quick_run_confirmation(self, change: dict[str, Any]) -> None:
        if change.get("old") != change.get("new"):
            self.quick_run_confirmation.value = False

    def _all_leg_altitude_changed(self, change: dict[str, Any]) -> None:
        self._invalidate_quick_run_confirmation(change)
        if (
            change.get("old") != change.get("new")
            and not self._setting_kml_altitude
        ):
            self._all_leg_altitude_user_edited = True

    def _seed_altitude_from_single_polygon(
        self,
        result: KmlImportResult,
    ) -> str | None:
        if self._all_leg_altitude_user_edited:
            return None
        if self.project is not None and (
            self.project.route_nodes or self.project.sections
        ):
            return None
        if result.points or result.lines or len(result.polygons) != 1:
            return None
        polygon = result.polygons[0]
        minimum_m = polygon.minimum_altitude_m
        maximum_m = polygon.maximum_altitude_m
        if (
            polygon.altitude_mode != "absolute"
            or minimum_m is None
            or maximum_m is None
            or not isfinite(minimum_m)
            or not isfinite(maximum_m)
            or maximum_m <= 0
            or not isclose(minimum_m, maximum_m, rel_tol=0, abs_tol=0.1)
        ):
            return None
        altitude_ft = int(round(maximum_m / FT_TO_M))
        if altitude_ft <= 0:
            return None
        self._setting_kml_altitude = True
        try:
            self.all_leg_altitude.value = float(altitude_ft)
        finally:
            self._setting_kml_altitude = False
        self.quick_run_confirmation.value = False
        return (
            f"absolute上限高度 {maximum_m:g} mを{altitude_ft:,} ftへ換算し、"
            "新規Legの全Leg ALTへ入力しました（計算前に確認が必要）"
        )

    def _add_imported_point(self, _: Any) -> None:
        if self.import_result is None or self.candidates.value is None:
            return
        point = self.import_result.points[self.candidates.value]
        self._append_node(point.name, point.latitude_deg, point.longitude_deg, "KML/KMZ")

    def _add_imported_shape(self, _: Any) -> None:
        if self.project is None:
            self._notify("先にProjectを作成してください。", error=True)
            return
        if self.import_result is None or self.shape_candidates.value is None:
            self._notify("Routeへ変換する形状を選択してください。", error=True)
            return
        kind, index = self.shape_candidates.value
        if kind == "line":
            line = self.import_result.lines[index]
            name = line.name
            coordinates = line.coordinates
            source = "KML/KMZ LineString"
        elif kind == "polygon":
            if not self.polygon_route_confirmation.value:
                self._notify(
                    "Polygonは空域・区域境界の可能性があります。"
                    "確認欄を選択してからRouteへ変換してください。",
                    error=True,
                )
                return
            polygon = self.import_result.polygons[index]
            name = polygon.name
            coordinates = polygon.outer_boundary
            source = "KML/KMZ Polygon (confirmed)"
        else:
            self._notify("未対応のKML形状です。", error=True)
            return
        route_coordinates: list[tuple[float, float]] = []
        for coordinate in coordinates:
            if not route_coordinates or coordinate != route_coordinates[-1]:
                route_coordinates.append(coordinate)
        if self.project.route_nodes and route_coordinates:
            last_node = self.project.ordered_nodes()[-1]
            if route_coordinates[0] == (
                last_node.latitude_deg,
                last_node.longitude_deg,
            ):
                route_coordinates.pop(0)
        if len(route_coordinates) < 2:
            self._notify("選択形状にはRoute化できる座標が不足しています。", error=True)
            return
        start_sequence = len(self.project.route_nodes)
        nodes = [
            RouteNode(
                project_id=self.project.id,
                sequence=start_sequence + offset,
                name=f"{name} {offset + 1:02d}",
                latitude_deg=latitude,
                longitude_deg=longitude,
                role=(
                    RouteNodeRole.AIRPORT
                    if start_sequence == 0 and offset == 0
                    else RouteNodeRole.ROUTE_POINT
                ),
                source=source,
            )
            for offset, (latitude, longitude) in enumerate(route_coordinates)
        ]
        self.project.route_nodes.extend(nodes)
        self._rebuild_sections()
        self._refresh_route()
        self._notify(f"{name}の{len(nodes)}点をRouteへ一括追加しました。")

    def _add_manual_point(self, _: Any) -> None:
        self._append_node(
            self.manual_name.value or "Route Point",
            self.manual_lat.value,
            self.manual_lon.value,
            "MANUAL",
        )

    def _append_node(self, name: str, latitude: float, longitude: float, source: str) -> None:
        if self.project is None:
            self._notify("先にProjectを作成してください。", error=True)
            return
        role = RouteNodeRole.AIRPORT if not self.project.route_nodes else RouteNodeRole.ROUTE_POINT
        self.project.route_nodes.append(
            RouteNode(
                project_id=self.project.id,
                sequence=len(self.project.route_nodes),
                name=name,
                latitude_deg=latitude,
                longitude_deg=longitude,
                role=role,
                source=source,
            )
        )
        self._rebuild_sections()
        self._refresh_route()

    def _delete_node(self, _: Any) -> None:
        if self.project is None or self.route.value is None:
            return
        self.project.route_nodes.pop(self.route.value)
        self._normalize_nodes()

    def _move_node(self, direction: int) -> None:
        if self.project is None or self.route.value is None:
            return
        source = self.route.value
        target = source + direction
        if not 0 <= target < len(self.project.route_nodes):
            return
        self.project.route_nodes[source], self.project.route_nodes[target] = (
            self.project.route_nodes[target],
            self.project.route_nodes[source],
        )
        self._normalize_nodes()
        self.route.value = target

    def _normalize_nodes(self) -> None:
        if self.project is None:
            return
        for index, node in enumerate(self.project.route_nodes):
            node.sequence = index
        self._rebuild_sections()
        self._refresh_route()

    def _rebuild_sections(self) -> None:
        if self.project is None:
            return
        previous_sections = {
            (section.from_node_id, section.to_node_id): section
            for section in self.project.sections
        }
        rebuilt: list[NavSection] = []
        for index, (start, end) in enumerate(
            zip(self.project.route_nodes, self.project.route_nodes[1:], strict=False)
        ):
            previous = previous_sections.get((start.id, end.id))
            if previous is None:
                rebuilt.append(
                    NavSection(
                        project_id=self.project.id,
                        sequence=index,
                        from_node_id=start.id,
                        to_node_id=end.id,
                        phase=FlightPhase.CRUISE,
                        planned_altitude_ft_msl=self.all_leg_altitude.value,
                    )
                )
            else:
                rebuilt.append(
                    previous.model_copy(
                        update={
                            "project_id": self.project.id,
                            "sequence": index,
                        }
                    )
                )
        self.project.sections = rebuilt

    def _apply_phase(self, _: Any) -> None:
        if self.project is None or self.route.value is None:
            return
        index = self.route.value
        if index >= len(self.project.sections):
            self._notify("最終点には出発Legがありません。", error=True)
            return
        direction = self._optional_float(self.wind_direction.value)
        speed = self._optional_float(self.wind_speed.value)
        if (direction is None) != (speed is None):
            self._notify("手動風は風向・風速を両方入力してください。", error=True)
            return
        self.project.sections[index] = NavSection.model_validate(
            self.project.sections[index].model_dump()
            | {
                "phase": FlightPhase(self.phase.value),
                "planned_altitude_ft_msl": self.altitude.value,
                "safe_enroute_altitude_ft_msl": self._optional_float(
                    self.safe_altitude.value
                ),
                "manual_wind_direction_deg": direction,
                "manual_wind_speed_kt": speed,
                "manual_temperature_c": self._optional_float(self.temperature.value),
                "manual_tas_kt": self._optional_float(self.tas.value),
                "loss_time_seconds": self.loss_time.value,
            },
        )
        self._refresh_route()

    def _apply_all_leg_altitude(self, _: Any) -> None:
        if self.project is None or not self.project.sections:
            self._notify("高度を適用するLegがありません。", error=True)
            return
        if self.all_leg_altitude.value <= 0:
            self._notify("全Leg ALT ftは0より大きい値を入力してください。", error=True)
            return
        count = len(self.project.sections)
        self.project.sections = [
            section.model_copy(
                update={
                    "planned_altitude_ft_msl": self.all_leg_altitude.value,
                }
            )
            for section in self.project.sections
        ]
        self._refresh_route()
        self._notify(
            f"明示操作により既存値を含む{count} Legの計画高度を"
            f"{self.all_leg_altitude.value:g} ftへ更新しました。"
        )

    def _refresh_route(self) -> None:
        if self.project is None:
            self.route.options = []
            return
        options: list[tuple[str, int]] = []
        for index, node in enumerate(self.project.route_nodes):
            if index >= len(self.project.sections):
                label = f"{index + 1}. {node.name}（終点）"
            else:
                section = self.project.sections[index]
                destination = self.project.route_nodes[index + 1]
                safe_altitude = (
                    "未入力"
                    if section.safe_enroute_altitude_ft_msl is None
                    else f"{section.safe_enroute_altitude_ft_msl:g} ft"
                )
                label = (
                    f"{index + 1}. {node.name} → {destination.name}"
                    f" / {section.phase.value} / SEA {safe_altitude}"
                )
            options.append((label, index))
        self.route.options = options
        self._refresh_map()

    def _route_selected(self, change: dict[str, Any]) -> None:
        if self.project is None or change["new"] is None:
            return
        index = change["new"]
        if index >= len(self.project.sections):
            return
        section = self.project.sections[index]
        self.phase.value = section.phase.value
        self.altitude.value = section.planned_altitude_ft_msl
        self.safe_altitude.value = self._optional_text(
            section.safe_enroute_altitude_ft_msl
        )
        self.wind_direction.value = self._optional_text(
            section.manual_wind_direction_deg
        )
        self.wind_speed.value = self._optional_text(section.manual_wind_speed_kt)
        self.temperature.value = self._optional_text(section.manual_temperature_c)
        self.tas.value = self._optional_text(section.manual_tas_kt)
        self.loss_time.value = section.loss_time_seconds

    def _refresh_map(self) -> None:
        coordinates: list[tuple[float, float]] = []
        if self.project is not None:
            coordinates.extend(
                (node.latitude_deg, node.longitude_deg)
                for node in self.project.ordered_nodes()
            )
        if self.import_result is not None:
            coordinates.extend(
                (point.latitude_deg, point.longitude_deg)
                for point in self.import_result.points
            )
            for line in self.import_result.lines:
                coordinates.extend(line.coordinates)
            for polygon in self.import_result.polygons:
                coordinates.extend(polygon.outer_boundary)
        if not coordinates:
            self.map_view.value = ""
            return
        map_widget = folium.Map(
            location=coordinates[0],
            zoom_start=8,
            control_scale=True,
        )
        if self.import_result is not None:
            selected_shape = self.shape_candidates.value
            for index, line in enumerate(self.import_result.lines):
                selected = selected_shape == ("line", index)
                folium.PolyLine(  # type: ignore[no-untyped-call]
                    line.coordinates,
                    color="#2471a3" if selected else "#7f8c8d",
                    weight=4 if selected else 2,
                    dash_array=None if selected else "5 5",
                    tooltip=f"{escape(line.name)} (LineString)",
                ).add_to(map_widget)
            for index, polygon in enumerate(self.import_result.polygons):
                selected = selected_shape == ("polygon", index)
                folium.Polygon(
                    locations=polygon.outer_boundary,
                    color="#c0392b" if selected else "#d35400",
                    weight=4 if selected else 2,
                    fill=True,
                    fill_color="#e67e22",
                    fill_opacity=0.18 if selected else 0.08,
                    tooltip=f"{escape(polygon.name)} (Polygon / 空域・区域境界)",
                ).add_to(map_widget)
                for inner_boundary in polygon.inner_boundaries:
                    folium.PolyLine(  # type: ignore[no-untyped-call]
                        inner_boundary,
                        color="#d35400",
                        weight=2,
                        dash_array="4 4",
                        tooltip=f"{escape(polygon.name)} (内周)",
                    ).add_to(map_widget)
        if self.project is not None:
            route = self.project.ordered_nodes()
            for node in route:
                folium.Marker(
                    (node.latitude_deg, node.longitude_deg),
                    tooltip=node.name,
                ).add_to(map_widget)
            if len(route) >= 2:
                folium.PolyLine(  # type: ignore[no-untyped-call]
                    [(node.latitude_deg, node.longitude_deg) for node in route],
                    color="#1f618d",
                    weight=4,
                ).add_to(map_widget)
        if len(coordinates) >= 2:
            map_widget.fit_bounds(coordinates)
        self.map_view.value = map_widget._repr_html_()

    def _ensure_pasted_import(self) -> KmlImportResult:
        pasted = self.kml_text.value
        if pasted.strip() and (
            self.import_result is None or pasted != self._imported_kml_text
        ):
            self._accept_import_result(import_kml_text(pasted))
            self._imported_kml_text = pasted
        if self.import_result is None:
            raise ValueError(
                "KML/XMLを貼り付けてください。ファイル取込済みの場合は通常の計算実行も"
                "利用できます。"
            )
        return self.import_result

    def _route_entries_from_import(
        self,
        result: KmlImportResult,
    ) -> tuple[list[RouteEntry], str]:
        selected = self.shape_candidates.value
        if len(result.lines) == 1:
            if selected != ("line", 0):
                confirmed = self.quick_run_confirmation.value
                self.shape_candidates.value = ("line", 0)
                self.quick_run_confirmation.value = confirmed
            line = result.lines[0]
            return (
                [
                    (
                        f"{line.name} {index + 1:02d}",
                        latitude,
                        longitude,
                        "KML/KMZ LineString",
                    )
                    for index, (latitude, longitude) in enumerate(line.coordinates)
                ],
                f"単一LineString「{line.name}」をKML記載順でRoute候補へ適用",
            )
        if len(result.lines) > 1:
            if (
                isinstance(selected, tuple)
                and len(selected) == 2
                and selected[0] == "line"
            ):
                line_index = selected[1]
                line = result.lines[line_index]
                return (
                    [
                        (
                            f"{line.name} {index + 1:02d}",
                            latitude,
                            longitude,
                            "KML/KMZ LineString",
                        )
                        for index, (latitude, longitude) in enumerate(
                            line.coordinates
                        )
                    ],
                    f"選択済みLineString「{line.name}」をKML記載順でRoute候補へ適用",
                )
            raise ValueError(
                "LineStringが複数あります。地図で飛行経路にする形状を1件選択してから"
                "もう一度実行してください。"
            )
        if result.points:
            return (
                [
                    (
                        point.name,
                        point.latitude_deg,
                        point.longitude_deg,
                        "KML/KMZ Point",
                    )
                    for point in result.points
                ],
                f"{len(result.points)}件のPointをKML記載順でRoute候補へ適用",
            )
        if result.polygons:
            polygon_index: int | None = None
            if (
                isinstance(selected, tuple)
                and len(selected) == 2
                and selected[0] == "polygon"
            ):
                polygon_index = selected[1]
            elif len(result.polygons) == 1:
                polygon_index = 0
                if selected != ("polygon", 0):
                    confirmed = self.quick_run_confirmation.value
                    self.shape_candidates.value = ("polygon", 0)
                    self.quick_run_confirmation.value = confirmed
            if polygon_index is None:
                raise ValueError(
                    "Polygonが複数あります。開始点・進行方向は自動判定できません。"
                    "地図で形状を1件選択してください。"
                )
            if not self.polygon_route_confirmation.value:
                self._require_quick_run_confirmation(polygon=True)
            polygon = result.polygons[polygon_index]
            return (
                [
                    (
                        f"{polygon.name} {index + 1:02d}",
                        latitude,
                        longitude,
                        "KML/KMZ Polygon (confirmed)",
                    )
                    for index, (latitude, longitude) in enumerate(
                        polygon.outer_boundary
                    )
                ],
                f"確認済みPolygon「{polygon.name}」をKML記載順でRoute候補へ適用",
            )
        raise ValueError(
            "Route化できるPoint、LineString、PolygonがKMLにありません。"
        )

    def _require_quick_run_confirmation(self, *, polygon: bool = False) -> None:
        if self.quick_run_confirmation.value:
            return
        details = (
            f"ETD JST={self.departure_time.value.strip() or '未入力'}、"
            f"新規Leg計画高度={self.all_leg_altitude.value:g} ft"
        )
        polygon_note = (
            "、およびPolygon境界の開始点・進行方向をKML記載順でRouteに使うこと"
            if polygon
            else ""
        )
        raise ValueError(
            f"{details}{polygon_note}は未確認です。地図と入力値を確認し、"
            "確認欄を選択してからもう一度実行してください。"
        )

    def _seed_airport_inputs(
        self,
        route_coordinates: list[tuple[float, float]],
    ) -> tuple[Airport, Airport, str | None]:
        airports = self.calculation_service.airports.all()
        if not airports:
            raise ValueError(
                "空港マスターが空のためFROM/TOを決定できません。"
                "airports.csvへ利用空港を登録してください。"
            )
        by_id = {airport.id: airport for airport in airports}
        by_icao = {airport.icao: airport for airport in airports}
        if self.project is not None:
            if not self.departure.value.strip():
                self.departure.value = self.project.departure_airport_id
            if not self.destination.value.strip():
                self.destination.value = self.project.destination_airport_id

        def entered_airport(value: str, label: str) -> Airport | None:
            identifier = value.strip()
            if not identifier:
                return None
            airport = by_id.get(identifier) or by_icao.get(identifier.upper())
            if airport is None:
                choices = ", ".join(airport.icao for airport in airports)
                raise ValueError(
                    f"{label}={identifier!r}は空港マスターにありません。候補: {choices}"
                )
            return airport

        departure = entered_airport(self.departure.value, "FROM")
        destination = entered_airport(self.destination.value, "TO")
        seeded = departure is None or destination is None

        def distance(
            coordinate: tuple[float, float],
            airport: Airport,
        ) -> float:
            return geodesic_leg(
                coordinate[0],
                coordinate[1],
                airport.latitude_deg,
                airport.longitude_deg,
            ).distance_nm

        if departure is None and destination is None and len(airports) == 2:
            first, second = airports
            if len(route_coordinates) >= 2:
                direct = distance(route_coordinates[0], first) + distance(
                    route_coordinates[-1], second
                )
                reverse = distance(route_coordinates[0], second) + distance(
                    route_coordinates[-1], first
                )
                departure, destination = (
                    (first, second) if direct <= reverse else (second, first)
                )
            else:
                departure, destination = first, second
        elif len(airports) == 1:
            departure = departure or airports[0]
            destination = destination or airports[0]
        else:
            if departure is None and route_coordinates:
                departure = min(
                    airports,
                    key=lambda airport: distance(route_coordinates[0], airport),
                )
            if destination is None and route_coordinates:
                destination = min(
                    airports,
                    key=lambda airport: distance(route_coordinates[-1], airport),
                )
            if len(airports) == 2:
                if departure is None and destination is not None:
                    departure = next(
                        (airport for airport in airports if airport.id != destination.id),
                        destination,
                    )
                if destination is None and departure is not None:
                    destination = next(
                        (airport for airport in airports if airport.id != departure.id),
                        departure,
                    )
        if departure is None or destination is None:
            choices = ", ".join(
                f"{airport.icao} ({airport.name})" for airport in airports
            )
            raise ValueError(
                "FROM/TOを自動決定できません。人の判断が必要です。"
                f"FROMとTO欄へ入力してください。空港マスター候補: {choices}"
            )
        self.departure.value = departure.id
        self.destination.value = destination.id
        note = (
            f"空港マスターからFROM={departure.icao}、TO={destination.icao}を自動入力"
            if seeded
            else None
        )
        return departure, destination, note

    def _install_route_from_import(
        self,
        departure: Airport,
        destination: Airport,
        entries: list[RouteEntry],
    ) -> int:
        if self.project is None:
            raise ValueError("Projectがありません。")
        if self.project.route_nodes:
            return 0
        filtered: list[RouteEntry] = []
        for entry in entries:
            coordinate = (entry[1], entry[2])
            if not filtered or coordinate != (filtered[-1][1], filtered[-1][2]):
                filtered.append(entry)
        departure_coordinate = (
            departure.latitude_deg,
            departure.longitude_deg,
        )
        destination_coordinate = (
            destination.latitude_deg,
            destination.longitude_deg,
        )
        if filtered and (filtered[0][1], filtered[0][2]) == departure_coordinate:
            filtered.pop(0)
        if filtered and (filtered[-1][1], filtered[-1][2]) == destination_coordinate:
            filtered.pop()
        route_specs: list[tuple[str, float, float, RouteNodeRole, str]] = [
            (
                departure.icao,
                departure.latitude_deg,
                departure.longitude_deg,
                RouteNodeRole.AIRPORT,
                f"AIRPORT_MASTER:{departure.source_revision}",
            ),
            *[
                (
                    name,
                    latitude,
                    longitude,
                    RouteNodeRole.ROUTE_POINT,
                    source,
                )
                for name, latitude, longitude, source in filtered
            ],
            (
                destination.icao,
                destination.latitude_deg,
                destination.longitude_deg,
                RouteNodeRole.DESTINATION,
                f"AIRPORT_MASTER:{destination.source_revision}",
            ),
        ]
        self.project.route_nodes = [
            RouteNode(
                project_id=self.project.id,
                sequence=index,
                name=name,
                latitude_deg=latitude,
                longitude_deg=longitude,
                role=role,
                source=source,
            )
            for index, (name, latitude, longitude, role, source) in enumerate(
                route_specs
            )
        ]
        self._rebuild_sections()
        self._initialize_imported_nav2_phases(destination)
        self._refresh_route()
        return len(self.project.route_nodes)

    def _initialize_imported_nav2_phases(self, destination: Airport) -> None:
        if self.project is None or not self.project.sections:
            return
        section_count = len(self.project.sections)
        phases = [FlightPhase.CRUISE] * section_count
        if section_count >= 4:
            phases[0] = FlightPhase.CLIMB
            phases[-2] = FlightPhase.DESCENT
            phases[-1] = FlightPhase.VISUAL_ARRIVAL
        elif section_count == 3:
            phases = [
                FlightPhase.CLIMB,
                FlightPhase.DESCENT,
                FlightPhase.VISUAL_ARRIVAL,
            ]
        elif section_count == 2:
            phases = [FlightPhase.CLIMB, FlightPhase.VISUAL_ARRIVAL]
        else:
            phases = [FlightPhase.VISUAL_ARRIVAL]
        visual_altitude = (
            destination.pattern_altitude_ft_msl
            if destination.pattern_altitude_ft_msl is not None
            else destination.elevation_ft_msl
        )
        self.project.sections = [
            section.model_copy(
                update={
                    "phase": phase,
                    "planned_altitude_ft_msl": (
                        visual_altitude
                        if phase == FlightPhase.VISUAL_ARRIVAL
                        else section.planned_altitude_ft_msl
                    ),
                }
            )
            for section, phase in zip(self.project.sections, phases, strict=True)
        ]
        self.project.metadata["auto_phase_assignment"] = {
            "method": "IMPORTED_NAV2_POSITIONAL_V1",
            "section_count": section_count,
            "phases": [phase.value for phase in phases],
            "visual_arrival_altitude_ft_msl": visual_altitude,
            "review_required": True,
        }

    def _calculate_from_pasted_kml(self, _: Any) -> None:
        steps: list[str] = []
        try:
            result = self._ensure_pasted_import()
            if self._kml_altitude_note is not None:
                steps.append(f"KML高度由来: {self._kml_altitude_note}")
            entries: list[RouteEntry] | None = None
            route_coordinates: list[tuple[float, float]]
            if self.project is None or not self.project.route_nodes:
                entries, route_decision = self._route_entries_from_import(result)
                route_coordinates = [
                    (latitude, longitude)
                    for _, latitude, longitude, _ in entries
                ]
                steps.append(route_decision)
            else:
                route_coordinates = [
                    (node.latitude_deg, node.longitude_deg)
                    for node in self.project.ordered_nodes()
                ]
                steps.append(
                    "既存RouteとLeg入力を保護し、貼付KMLでは自動置換していません"
                )
            self._require_quick_run_confirmation()
            departure, destination, airport_note = self._seed_airport_inputs(
                route_coordinates
            )
            if airport_note:
                steps.append(airport_note)
            if self.project is None:
                self._create_project_from_inputs()
                steps.append("入力欄からProjectを作成")
            if self.project is None:
                raise ValueError("Projectを作成できませんでした。")
            self.project.departure_airport_id = departure.id
            self.project.destination_airport_id = destination.id
            if not self.project.route_nodes:
                if entries is None:
                    raise ValueError("Route候補がありません。")
                if self.all_leg_altitude.value <= 0:
                    raise ValueError(
                        "全Leg ALT ftは0より大きい値を入力してください。"
                    )
                node_count = self._install_route_from_import(
                    departure,
                    destination,
                    entries,
                )
                steps.append(
                    f"空港を含む{node_count}点と{len(self.project.sections)} Legを作成"
                )
                steps.append(
                    f"新規Legへ計画高度{self.all_leg_altitude.value:g} ftを適用"
                )
                steps.append(
                    "Phase初期案を位置規則で設定: "
                    + " → ".join(section.phase.value for section in self.project.sections)
                    + "（飛行前に確認してください）"
                )
            outcome = self._calculate_project()
            steps.append(f"NAV LOG計算完了: {outcome.status.value}")
            missing_sea_count = sum(
                issue.code == "SAFE_ENROUTE_ALTITUDE_REQUIRED"
                for issue in outcome.blockers
            )
            if missing_sea_count:
                steps.append(
                    f"SEA未入力の{missing_sea_count} Legがあります。Route欄で各Legを"
                    "選び、SEAを入力して「Legへ適用」後、再計算してください"
                )
            self._set_quick_run_status(steps)
            self._notify(f"計算状態: {outcome.status.value}")
        except Exception as error:
            steps.append(str(error))
            self._set_quick_run_status(steps, error=True)
            self._notify(str(error), error=True)

    def _set_quick_run_status(
        self,
        messages: list[str],
        *,
        error: bool = False,
    ) -> None:
        color = "#922b21" if error else "#1e8449"
        title = "確認・入力が必要" if error else "ワンクリック処理結果"
        items = "".join(f"<li>{escape(message)}</li>" for message in messages)
        self.quick_run_status.value = (
            f"<div style='color:{color}'><strong>{title}</strong><ol>{items}</ol></div>"
        )

    def _calculate(self, _: Any) -> None:
        try:
            outcome = self._calculate_project()
            self._notify(f"計算状態: {outcome.status.value}")
        except Exception as error:
            self._notify(str(error), error=True)

    def _calculate_project(self) -> CalculationOutcome:
        if self.project is None:
            raise ValueError("Projectがありません。")
        self.project.total_usable_fuel_gal = self.fuel.value
        self.project.default_variation_deg_east = self.variation.value
        self.project.manual_qnh_hpa = self._optional_float(self.manual_qnh.value)
        self.project.tgl_count = self.tgl_count.value
        outcome = self.calculation_service.calculate(
            self.project,
            self.weather_provider,
        )
        self.project = self.project_service.apply_calculation_outcome(
            self.project,
            outcome,
        )
        self.outcome = outcome
        self.run_label.value = (
            f"<strong>Forecast Run:</strong> "
            f"{outcome.selected_forecast_run_id or '未確定'}"
        )
        self._render_issues()
        self.clearcopy.value = render_clearcopy_html(self.project, outcome)
        return outcome

    def _render_issues(self) -> None:
        if self.outcome is None:
            self.issues.children = ()
            return
        children: list[widgets.Widget] = []
        for issue in self.outcome.issues:
            location = (
                ""
                if issue.segment_sequence is None
                else f" [Leg/Seg {issue.segment_sequence + 1}]"
            )
            if issue.acknowledgement_required:
                checkbox = widgets.Checkbox(
                    description=f"{issue.code}{location}: {issue.message}",
                    value=issue.code
                    in (
                        self.project.acknowledged_warning_codes
                        if self.project
                        else set()
                    ),
                    indent=False,
                )
                checkbox.observe(
                    lambda change, code=issue.code: self._acknowledge(code, change["new"]),
                    names="value",
                )
                children.append(checkbox)
            else:
                children.append(
                    widgets.HTML(
                        f"<strong>{issue.severity.value} {issue.code}"
                        f"{location}</strong>: {issue.message}"
                    )
                )
        self.issues.children = tuple(children)

    def write_transfer_aid_html(self) -> Path:
        if self.project is None or self.outcome is None:
            raise ValueError("先にNAV LOG計算を実行してください。")
        output_directory = self.download_directory
        if output_directory is None:
            content_directory = Path("/content")
            output_directory = (
                content_directory if content_directory.is_dir() else Path.cwd()
            )
        output_directory.mkdir(parents=True, exist_ok=True)
        destination = (
            output_directory
            / f"AutoNavLog_transfer_aid_{self.project.id}.html"
        )
        destination.write_text(
            render_transfer_aid_document(self.project, self.outcome),
            encoding="utf-8",
        )
        return destination

    def _download_transfer_aid(self, _: Any) -> None:
        try:
            destination = self.write_transfer_aid_html()
            try:
                from google.colab import files  # type: ignore[import-not-found]
            except ImportError:
                self.download_transfer_aid_status.value = (
                    "<strong>A4印刷用HTMLを保存しました:</strong> "
                    f"{escape(str(destination))}"
                )
            else:
                files.download(str(destination))
                self.download_transfer_aid_status.value = (
                    "<strong>ダウンロードを開始しました:</strong> "
                    f"{escape(destination.name)}"
                )
        except Exception as error:
            self.download_transfer_aid_status.value = (
                f"<strong style='color:#922b21'>{escape(str(error))}</strong>"
            )

    def _acknowledge(self, code: str, checked: bool) -> None:
        if self.project is None:
            return
        if checked:
            self.project.acknowledged_warning_codes.add(code)
        else:
            self.project.acknowledged_warning_codes.discard(code)

    def _save(self, _: Any) -> None:
        if self.project is None:
            return
        try:
            saved = self.project_service.save(self.project)
            self.project = saved.project
            self._notify(f"保存しました: revision {self.project.revision}")
        except Exception as error:
            self._notify(str(error), error=True)

    def _snapshot(self, _: Any) -> None:
        if self.project is None or self.outcome is None:
            self._notify("計算後にSnapshotを作成してください。", error=True)
            return
        try:
            path = self.project_service.snapshot(
                self.project,
                self.outcome,
                self.calculation_service,
                msm_package_version=getattr(self.weather_provider, "package_version", None),
            )
            self._notify(f"Snapshotを作成しました: {path.name}")
        except Exception as error:
            self._notify(str(error), error=True)

    def _notify(self, message: str, *, error: bool = False) -> None:
        color = "#922b21" if error else "#1e8449"
        self.message.value = f"<p style='color:{color}'>{message}</p>"

    @staticmethod
    def _optional_float(value: str) -> float | None:
        stripped = value.strip()
        return None if not stripped else float(stripped)

    @staticmethod
    def _optional_text(value: float | None) -> str:
        return "" if value is None else f"{value:g}"
