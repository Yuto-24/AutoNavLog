from __future__ import annotations

from collections.abc import Callable
from html import escape
from typing import Any

from autonavlog.domain.calculation import CalculationOutcome, SectionResult
from autonavlog.domain.enums import ProjectStatus, ValueState
from autonavlog.domain.project import Project
from autonavlog.domain.values import AdoptedValue

from .formatting import ROUNDING, format_clock, format_duration

DISCLAIMER = (
    "この出力は航空大学校「別添8-1」の複製、公式様式、承認済み運航資料ではありません。"
    "計算値を原票へ手書きで転記するための補助表です。"
    "利用者が適用規定、性能資料、WX、警告および原票の欄と照合してください。"
)


def _text_cell(value: str, css_class: str = "") -> str:
    class_attribute = f" class='{css_class}'" if css_class else ""
    return f"<td{class_attribute}>{escape(value)}</td>"


def _value_cell(
    value: AdoptedValue[Any],
    formatter: Callable[[Any], str] = str,
    css_class: str = "num",
) -> str:
    adopted = value.adopted()
    shown = "未確定" if adopted is None else formatter(adopted)
    classes = css_class + (" missing" if adopted is None else "")
    return (
        f"<td class='{classes}' title='{escape(value.state.value)}'>"
        f"{escape(shown)}</td>"
    )


def _optional_number(value: float | None, formatter: Callable[[float], str]) -> str:
    return "未確定" if value is None else formatter(value)


def _format_wind(result: SectionResult) -> str:
    speed = result.wind_speed_kt.adopted()
    direction = result.wind_direction_deg_from.adopted()
    if speed == 0:
        return "CALM"
    if speed is None or direction is None:
        return "未確定"
    return f"{ROUNDING.bearing(direction):03.0f}/{ROUNDING.wind(speed):.0f}"


def _phase_label(result: SectionResult) -> str:
    return {
        "CLIMB": "CLIMB",
        "CRUISE": "CRUISE",
        "DESCENT": "DESC",
        "VISUAL_ARRIVAL": "VIS ARR",
    }.get(result.phase.value, result.phase.value)


def _section_row(result: SectionResult) -> str:
    wind_missing = (
        result.wind_speed_kt.adopted() is None
        or (
            result.wind_speed_kt.adopted() != 0
            and result.wind_direction_deg_from.adopted() is None
        )
    )
    wind_class = "num missing" if wind_missing else "num"
    cells = [
        _text_cell(str(result.sequence + 1), "num"),
        _text_cell(_phase_label(result), "phase"),
        _text_cell(result.from_name, "route-name"),
        _text_cell(result.to_name, "route-name"),
        _value_cell(result.planned_altitude_ft_msl, lambda value: f"{value:.0f}"),
        _value_cell(result.pressure_altitude_planning_ft, lambda value: f"{value:.0f}"),
        _value_cell(result.safe_enroute_altitude_ft_msl, lambda value: f"{value:.0f}"),
        _value_cell(
            result.true_course_deg,
            lambda value: f"{ROUNDING.bearing(value):03.0f}",
        ),
        _value_cell(result.variation_deg_east, lambda value: f"{value:+.0f}"),
        _value_cell(
            result.magnetic_course_deg,
            lambda value: f"{ROUNDING.bearing(value):03.0f}",
        ),
        _text_cell(_format_wind(result), wind_class),
        _value_cell(result.wca_deg, lambda value: f"{value:+.0f}"),
        _value_cell(
            result.magnetic_heading_deg,
            lambda value: f"{ROUNDING.bearing(value):03.0f}",
        ),
        _value_cell(
            result.temperature_c,
            lambda value: f"{ROUNDING.temperature(value):.0f}",
        ),
        _value_cell(result.cas_kt, lambda value: f"{value:.0f}"),
        _value_cell(result.tas_kt, lambda value: f"{value:.0f}"),
        _value_cell(result.ground_speed_kt, lambda value: f"{value:.0f}"),
        _value_cell(
            result.zone_distance_nm,
            lambda value: f"{ROUNDING.distance(value):.1f}",
        ),
        _value_cell(
            result.cumulative_distance_nm,
            lambda value: f"{ROUNDING.distance(value):.1f}",
        ),
        _text_cell(format_duration(result.loss_time_seconds), "num"),
        _value_cell(result.zone_ete_seconds, format_duration),
        _value_cell(result.cumulative_ete_seconds, format_duration),
        _value_cell(result.eto_utc, format_clock),
        _value_cell(
            result.section_fuel_gal,
            lambda value: f"{ROUNDING.fuel(value):.1f}",
        ),
        _value_cell(
            result.remaining_fuel_gal,
            lambda value: f"{ROUNDING.fuel(value):.1f}",
        ),
    ]
    return "<tr>" + "".join(cells) + "</tr>"


def _project_summary(project: Project, outcome: CalculationOutcome) -> str:
    total_distance = (
        outcome.sections[-1].cumulative_distance_nm.adopted()
        if outcome.sections
        else None
    )
    total_time = (
        outcome.sections[-1].cumulative_ete_seconds.adopted()
        if outcome.sections
        else None
    )
    qnh = outcome.qnh_hpa.adopted()
    automatic_qnh_label = outcome.qnh_hpa.automatic_metadata.get("label")
    qnh_label = (
        "QNH (手動)"
        if outcome.qnh_hpa.state == ValueState.MANUAL_OVERRIDE
        else (
            automatic_qnh_label.strip()
            if isinstance(automatic_qnh_label, str)
            and automatic_qnh_label.strip()
            else "自動QNH"
        )
    )
    values = [
        ("PILOT", project.pilot_name or "未入力"),
        ("DATE", project.flight_date.isoformat()),
        ("SHIP", project.ship_identifier or "未入力"),
        ("FROM / TO", f"{project.departure_airport_id} / {project.destination_airport_id}"),
        ("ETD JST", project.planned_departure_time_jst.strftime("%H:%M")),
        (
            qnh_label,
            _optional_number(
                qnh,
                lambda value: f"{ROUNDING.qnh(value):.0f} hPa",
            ),
        ),
        (
            "TTL DIST nm",
            _optional_number(
                total_distance,
                lambda value: f"{ROUNDING.distance(value):.1f}",
            ),
        ),
        ("TTL ETE", _optional_number(total_time, format_duration)),
        ("FORECAST RUN", outcome.selected_forecast_run_id or "未確定"),
        ("POLICY", outcome.policy_version),
    ]
    cells = "".join(
        f"<th>{escape(label)}</th><td>{escape(value)}</td>"
        for label, value in values
    )
    return f"<table class='meta-table'><tbody><tr>{cells}</tr></tbody></table>"


def _derived_points_table(outcome: CalculationOutcome) -> str:
    sections = {section.section_id: section for section in outcome.sections}
    rows: list[str] = []
    for point in outcome.derived_points:
        section = sections.get(point.section_id)
        leg = (
            "不明"
            if section is None
            else f"{section.from_name} → {section.to_name}"
        )
        estimated = (
            "未確定"
            if point.estimated_time_utc is None
            else format_clock(point.estimated_time_utc)
        )
        rows.append(
            "<tr>"
            f"<td>{escape(point.type.value)}</td>"
            f"<td>{escape(leg)}</td>"
            f"<td class='num'>{ROUNDING.distance(point.along_route_distance_nm):.1f}</td>"
            f"<td class='num'>{point.latitude_deg:.5f}</td>"
            f"<td class='num'>{point.longitude_deg:.5f}</td>"
            f"<td class='num'>{escape(estimated)}</td>"
            "</tr>"
        )
    body = "".join(rows) or "<tr><td colspan='6'>なし</td></tr>"
    return f"""
<table class="support-table derived-table">
  <thead><tr><th>TYPE</th><th>LEG</th><th>ALONG DIST<br><small>nm</small></th>
    <th>LAT</th><th>LON</th><th>ETO<br><small>JST</small></th></tr></thead>
  <tbody>{body}</tbody>
</table>
"""


def _fuel_table(outcome: CalculationOutcome) -> str:
    fuel = outcome.fuel_plan
    values = [
        ("TOTAL", fuel.total_usable_gal),
        ("TAXI/RUN-UP", fuel.taxi_runup_gal),
        ("CLIMB", fuel.climb_gal),
        ("CRUISE", fuel.cruise_gal),
        ("DESC/ARR", fuel.descent_gal),
        ("ADDITIONAL", fuel.additional_gal),
        ("TGL", fuel.tgl_gal),
        ("RESERVE", fuel.reserve_gal),
        ("MIN REQUIRED", fuel.min_required_gal),
        ("EXTRA", fuel.extra_gal),
    ]
    headers = "".join(f"<th>{escape(label)}</th>" for label, _ in values)
    cells = "".join(
        "<td class='num'>"
        + escape(
            _optional_number(
                value,
                lambda item: f"{ROUNDING.fuel(item):.1f}",
            )
        )
        + "</td>"
        for _, value in values
    )
    endurance = _optional_number(fuel.extra_endurance_seconds, format_duration)
    return f"""
<table class="support-table fuel-table">
  <thead><tr>{headers}<th>EXTRA ENDURANCE</th></tr></thead>
  <tbody><tr>{cells}<td class="num">{escape(endurance)}</td></tr></tbody>
</table>
"""


def _segment_sequence_label(sequences: list[int | None]) -> str:
    if not sequences:
        return "-"

    has_project_issue = None in sequences
    numbered = sorted({sequence + 1 for sequence in sequences if sequence is not None})
    ranges: list[str] = []
    if numbered:
        start = previous = numbered[0]
        for number in numbered[1:]:
            if number == previous + 1:
                previous = number
                continue
            ranges.append(str(start) if start == previous else f"{start}–{previous}")
            start = previous = number
        ranges.append(str(start) if start == previous else f"{start}–{previous}")

    labels = ["全体"] if has_project_issue else []
    labels.extend(ranges)
    return ", ".join(labels)


def _issues_table(outcome: CalculationOutcome) -> str:
    grouped: dict[tuple[str, str, str, bool], list[int | None]] = {}
    for issue in outcome.issues:
        key = (
            issue.severity.value,
            issue.code,
            issue.message,
            issue.acknowledgement_required,
        )
        grouped.setdefault(key, []).append(issue.segment_sequence)

    rows = "".join(
        "<tr>"
        f"<td class='{severity.lower()}'>{escape(severity)}</td>"
        f"<td class='num'>{escape(_segment_sequence_label(sequences))}</td>"
        f"<td>{escape(code)}</td>"
        f"<td>{escape(message)}</td>"
        "</tr>"
        for (severity, code, message, _acknowledgement_required), sequences in grouped.items()
    )
    if not rows:
        rows = "<tr><td colspan='4'>なし</td></tr>"
    return f"""
<table class="support-table issues-table">
  <thead><tr><th>SEVERITY</th><th>SEG</th><th>CODE</th><th>警告・未確定内容</th></tr></thead>
  <tbody>{rows}</tbody>
</table>
"""


def render_transfer_aid_html(project: Project, outcome: CalculationOutcome) -> str:
    """Render an unofficial, dense transcription aid for A4 landscape printing."""

    ready = outcome.status == ProjectStatus.READY_FOR_COPY
    status_label = "転記可（要照合）" if ready else "転記不可"
    status_class = "transfer-ready" if ready else "transfer-blocked"
    section_rows = "".join(_section_row(result) for result in outcome.sections)
    if not section_rows:
        section_rows = "<tr><td class='missing' colspan='25'>Section計算結果なし</td></tr>"
    return f"""
<style>
@page {{ size: A4 landscape; margin: 8mm; }}
.autonavlog-transfer-aid {{
  color:#111; background:#fff;
  font-family:"Noto Sans CJK JP","Noto Sans JP","Yu Gothic","Hiragino Sans",
    Meiryo,Arial,sans-serif;
  max-width:1500px; margin:0 auto; padding:10px; line-height:1.15;
}}
.transfer-heading {{ display:flex; align-items:flex-end; justify-content:space-between;
  gap:10px; border-bottom:2px solid #111; padding-bottom:4px; }}
.transfer-heading h2 {{ font-size:18px; margin:0; }}
.transfer-heading .sub {{ font-size:9px; color:#444; }}
.transfer-status {{ font-size:15px; font-weight:800; border:2px solid;
  padding:4px 10px; white-space:nowrap; }}
.transfer-ready {{ color:#145a32; border-color:#145a32; background:#eafaf1; }}
.transfer-blocked {{ color:#b00020; border-color:#b00020; background:#fdeced; }}
.transfer-disclaimer {{ border:1.5px solid #b00020; margin:5px 0; padding:4px 6px;
  font-size:9px; font-weight:700; color:#7b0016; }}
.transfer-scroll {{ overflow-x:auto; }}
.autonavlog-transfer-aid table {{ border-collapse:collapse; width:100%; }}
.autonavlog-transfer-aid th,.autonavlog-transfer-aid td {{
  border:1px solid #555; padding:2px 3px; vertical-align:middle;
}}
.autonavlog-transfer-aid th {{ background:#e9ecef; font-weight:700; text-align:center; }}
.meta-table {{ font-size:7px; table-layout:auto; margin-bottom:4px; }}
.meta-table th {{ white-space:nowrap; }}
.meta-table td {{ min-width:30px; }}
.route-table {{ table-layout:fixed; font-size:6px; line-height:1.05; }}
.route-table th {{ white-space:normal; overflow-wrap:anywhere; }}
.route-table td {{ white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
.route-table .route-name {{ white-space:normal; overflow-wrap:anywhere; }}
.route-table .phase {{ white-space:normal; font-size:5.5px; }}
.num {{ text-align:right; font-variant-numeric:tabular-nums; }}
.missing {{ color:#b00020; background:#fff0f0; font-weight:700; }}
.support-grid {{ display:grid; grid-template-columns:1fr 1.25fr; gap:5px; margin-top:5px; }}
.support-grid h3,.issues-wrap h3 {{ font-size:8px; margin:0 0 2px; }}
.support-table {{ table-layout:auto; font-size:6.5px; }}
.support-table small,.route-table small {{ font-size:5px; font-weight:400; }}
.fuel-table {{ table-layout:fixed; }}
.issues-wrap {{ margin-top:5px; }}
.issues-table td:last-child {{ text-align:left; }}
.blocker {{ color:#b00020; font-weight:800; }}
.warning {{ color:#7d5900; font-weight:700; }}
.print-footer {{ display:flex; justify-content:space-between; margin-top:4px;
  font-size:6px; color:#333; }}
@media print {{
  html,body {{ margin:0; padding:0; background:#fff; }}
  .autonavlog-transfer-aid {{ max-width:none; width:auto; margin:0; padding:0; }}
  .transfer-scroll {{ overflow:visible; }}
  .transfer-heading h2 {{ font-size:12pt; }}
  .transfer-status {{ font-size:9pt; }}
  .transfer-disclaimer {{ font-size:6.5pt; }}
  .meta-table {{ font-size:5.2pt; }}
  .route-table {{ font-size:4.8pt; line-height:1; }}
  .route-table th,.route-table td {{ padding:.55mm .35mm; }}
  .support-table {{ font-size:5.2pt; }}
  .support-grid,.issues-wrap,.route-table tr {{ break-inside:avoid; }}
}}
</style>
<main class="autonavlog-transfer-aid">
  <header class="transfer-heading">
    <div><h2>AutoNavLog 転記補助表（非公式）</h2>
      <div class="sub">地上準備・原票への手書き転記補助専用</div></div>
    <div class="transfer-status {status_class}">{status_label}<br>
      <small>{escape(outcome.status.value)}</small></div>
  </header>
  <div class="transfer-disclaimer">{escape(DISCLAIMER)}</div>
  {_project_summary(project, outcome)}
  <div class="transfer-scroll">
    <table class="route-table">
      <thead><tr>
        <th>#</th><th>PHASE</th><th>FROM</th><th>TO</th>
        <th>ALT<br><small>ft</small></th><th>PA<br><small>ft</small></th>
        <th>SEA<br><small>ft</small></th><th>TC<br><small>°T</small></th>
        <th>VAR<br><small>°E</small></th><th>MC<br><small>°M</small></th>
        <th>WIND<br><small>°/kt</small></th><th>WCA<br><small>°</small></th>
        <th>MH<br><small>°M</small></th><th>OAT<br><small>°C</small></th>
        <th>CAS<br><small>kt</small></th><th>TAS<br><small>kt</small></th>
        <th>GS<br><small>kt</small></th><th>ZONE DIST<br><small>nm</small></th>
        <th>CUM DIST<br><small>nm</small></th><th>LOSS<br><small>min</small></th>
        <th>ZONE ETE<br><small>min</small></th><th>CUM ETE<br><small>min</small></th>
        <th>ETO<br><small>JST</small></th><th>SECT FUEL<br><small>gal</small></th>
        <th>REM FUEL<br><small>gal</small></th>
      </tr></thead>
      <tbody>{section_rows}</tbody>
    </table>
  </div>
  <div class="support-grid">
    <section><h3>DERIVED POINTS</h3>{_derived_points_table(outcome)}</section>
    <section><h3>FUEL SUMMARY（gal）</h3>{_fuel_table(outcome)}</section>
  </div>
  <section class="issues-wrap"><h3>警告・未確定項目</h3>{_issues_table(outcome)}</section>
  <footer class="print-footer"><span>Policy: {escape(outcome.policy_version)}</span>
    <span>Performance: {escape(outcome.performance_table_version or "未確定")}</span></footer>
</main>
"""


def render_transfer_aid_document(
    project: Project,
    outcome: CalculationOutcome,
) -> str:
    """Render a standalone UTF-8 A4 document that can be opened and printed."""

    aid = render_transfer_aid_html(project, outcome)
    return f"""<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(project.name)} - AutoNavLog 転記補助表（非公式）</title>
  <style>
    .print-controls {{ max-width:1500px; margin:8px auto; text-align:right; }}
    .print-controls button {{ font-size:16px; padding:8px 18px; cursor:pointer; }}
    @media print {{ .print-controls {{ display:none; }} }}
  </style>
</head>
<body>
  <div class="print-controls">
    <button type="button" onclick="window.print()">A4横で印刷</button>
  </div>
  {aid}
</body>
</html>
"""
