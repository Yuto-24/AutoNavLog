from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from math import isfinite
from typing import Any
from uuid import UUID

from autonavlog.domain.calculation import (
    CalculationOutcome,
    DerivedRoutePoint,
    FuelPlan,
    Issue,
    IterationRecord,
    SectionResult,
)
from autonavlog.domain.enums import (
    AdoptedSource,
    Availability,
    DerivedPointType,
    FlightPhase,
    IssueSeverity,
    Pa500Policy,
    ProjectStatus,
    ValueState,
    WeatherRequestKind,
)
from autonavlog.domain.project import Airport, NavSection, Project, RouteNode
from autonavlog.domain.values import AdoptedValue
from autonavlog.domain.weather import ForecastRequirement, WeatherRequest, WeatherResult
from autonavlog.nav.airspeed import (
    cas_from_tas,
    isa_temperature_c,
    pressure_altitude_exact_ft,
    pressure_altitude_planning_ft,
    tas_from_cas,
)
from autonavlog.nav.fuel import build_fuel_plan, fuel_for_section, remaining_fuel
from autonavlog.nav.geodesy import (
    GeodesicLeg,
    geodesic_leg,
)
from autonavlog.nav.wind_triangle import WindTriangleError, solve_wind_triangle
from autonavlog.performance.climb import ClimbCalculator, ClimbPerformanceError
from autonavlog.performance.cruise import (
    CruisePerformanceError,
    CruisePerformanceSelectionPolicy,
)
from autonavlog.performance.repository import PerformanceDataError, PerformanceRepository
from autonavlog.storage.airports import AirportRepository
from autonavlog.weather.provider import WeatherProvider

from .forecast_service import ForecastService
from .phase_segments import (
    PhaseSegmentation,
    PhaseSegmentationError,
    PhysicalRouteLeg,
    split_route_into_phase_segments,
)


@dataclass(frozen=True)
class CalculationPolicies:
    version: str = "nav2-v1"
    pa_500_policy: Pa500Policy = Pa500Policy.CEILING
    max_iterations: int = 5
    convergence_seconds: float = 30.0
    phase_boundary_distance_tolerance_nm: float = 0.25


@dataclass(frozen=True)
class _Geometry:
    section: NavSection
    start: RouteNode
    end: RouteNode
    geodesic: GeodesicLeg
    true_course_deg: float
    distance_nm: float


@dataclass(frozen=True)
class _LegEnvironment:
    geometry: _Geometry
    weather: WeatherResult | None
    wind_direction_deg_from: float | None
    wind_speed_kt: float | None
    temperature_c: float | None
    weather_metadata: dict[str, Any]
    weather_warnings: tuple[str, ...]
    pressure_altitude_exact_ft: float
    pressure_altitude_planning_ft: float


@dataclass(frozen=True)
class _ClimbPlan:
    source_section_id: UUID
    duration_seconds: float
    fuel_gal: float
    tas_kt: float
    route_end_distance_nm: float
    metadata: dict[str, Any]


@dataclass(frozen=True)
class _DescentPlan:
    source_section_id: UUID
    duration_seconds: float
    route_start_distance_nm: float
    route_end_distance_nm: float
    cruise_cas_kt: float
    metadata: dict[str, Any]


@dataclass(frozen=True)
class _RouteTraversal:
    distance_nm: float | None
    route_exhausted: bool = False


@dataclass
class _IterationResult:
    sections: list[SectionResult]
    issues: list[Issue]
    representative_times: dict[str, datetime]
    phases: list[FlightPhase]
    section_fuels: list[float | None]
    derived_points: list[DerivedRoutePoint]


def _automatic(
    value: Any,
    state: ValueState = ValueState.AUTO,
    metadata: dict[str, Any] | None = None,
    warnings: tuple[str, ...] = (),
) -> AdoptedValue[Any]:
    return AdoptedValue(
        automatic_value=value,
        automatic_status=state,
        automatic_metadata=metadata or {},
        adopted_source=AdoptedSource.AUTOMATIC if value is not None else None,
        warnings=warnings,
    )


def _manual_or_automatic(
    automatic: Any,
    manual: Any,
    *,
    state: ValueState = ValueState.AUTO,
    metadata: dict[str, Any] | None = None,
    warnings: tuple[str, ...] = (),
) -> AdoptedValue[Any]:
    return AdoptedValue(
        automatic_value=automatic,
        automatic_status=state if automatic is not None else ValueState.UNAVAILABLE,
        automatic_metadata=metadata or {},
        manual_override=manual,
        adopted_source=(
            AdoptedSource.MANUAL
            if manual is not None
            else AdoptedSource.AUTOMATIC
            if automatic is not None
            else None
        ),
        warnings=warnings,
    )


def _unavailable() -> AdoptedValue[Any]:
    return AdoptedValue(automatic_status=ValueState.UNAVAILABLE)


class CalculationService:
    def __init__(
        self,
        airports: AirportRepository,
        performance: PerformanceRepository,
        policies: CalculationPolicies | None = None,
        forecast_service: ForecastService | None = None,
    ):
        self.airports = airports
        self.performance = performance
        self.policies = policies or CalculationPolicies()
        self.forecast_service = forecast_service or ForecastService()
        self.last_weather_requests: list[WeatherRequest] = []
        self.last_weather_results: list[WeatherResult] = []
        self.last_forecast_metadata: dict[str, Any] = {}

    def calculate(self, project: Project, provider: WeatherProvider) -> CalculationOutcome:
        working = project.model_copy(deep=True)
        issues: list[Issue] = []
        self.last_weather_requests = []
        self.last_weather_results = []
        self.last_forecast_metadata = {}
        geometries = self._build_geometry(working, issues)
        try:
            departure = self.airports.get(working.departure_airport_id)
            destination = self.airports.get(working.destination_airport_id)
        except KeyError as error:
            issues.append(self._blocker("AIRPORT_DATA_UNAVAILABLE", str(error)))
            return self._empty_outcome(working, issues)
        if not geometries:
            return self._empty_outcome(working, issues)
        departure_gap_nm = geodesic_leg(
            departure.latitude_deg,
            departure.longitude_deg,
            geometries[0].start.latitude_deg,
            geometries[0].start.longitude_deg,
        ).distance_nm
        destination_gap_nm = geodesic_leg(
            geometries[-1].end.latitude_deg,
            geometries[-1].end.longitude_deg,
            destination.latitude_deg,
            destination.longitude_deg,
        ).distance_nm
        if departure_gap_nm > 0.5 or destination_gap_nm > 0.5:
            issues.append(
                Issue(
                    code="ROUTE_AIRPORT_ENDPOINT_MISMATCH",
                    severity=IssueSeverity.BLOCKER,
                    message=(
                        "経路の先頭・末尾が選択した出発地・目的地と一致しません。"
                    ),
                    metadata={
                        "departure_gap_nm": departure_gap_nm,
                        "destination_gap_nm": destination_gap_nm,
                        "tolerance_nm": 0.5,
                    },
                )
            )
            return self._empty_outcome(working, issues)

        initial_requirement = self.forecast_service.build_initial_requirement(working)
        selected_run_id = self._select_and_prepare_run(
            working,
            provider,
            initial_requirement,
            issues,
        )
        if selected_run_id is None and working.manual_qnh_hpa is None:
            return self._empty_outcome(working, issues)

        previous_times: dict[str, datetime] = {}
        iteration_records: list[IterationRecord] = []
        final: _IterationResult | None = None
        qnh_value: AdoptedValue[float] = _manual_or_automatic(
            None,
            working.manual_qnh_hpa,
        )
        converged = False
        for iteration in range(1, self.policies.max_iterations + 1):
            requests = self._weather_requests(
                working,
                departure,
                destination,
                geometries,
                previous_times,
            )
            results = self._query_weather(provider, selected_run_id, requests, issues)
            qnh_value = self._adopt_qnh(working, results)
            adopted_qnh = qnh_value.adopted()
            if adopted_qnh is None:
                issues.append(
                    self._blocker(
                        "QNH_UNAVAILABLE",
                        "自動QNHを取得できません。手動QNHが必要です。",
                    )
                )
                break
            iteration_result = self._calculate_iteration(
                working,
                departure,
                destination,
                geometries,
                results,
                adopted_qnh,
            )
            final = iteration_result
            delta = self._maximum_time_delta(previous_times, iteration_result.representative_times)
            iteration_records.append(
                IterationRecord(
                    iteration=iteration,
                    max_time_delta_seconds=delta,
                    representative_times_utc=iteration_result.representative_times,
                )
            )
            if previous_times and delta is not None and delta < self.policies.convergence_seconds:
                converged = True
                break
            previous_times = iteration_result.representative_times

        if final is None:
            outcome = self._empty_outcome(working, self._deduplicate_issues(issues))
            return outcome.model_copy(
                update={
                    "selected_forecast_run_id": selected_run_id,
                    "qnh_hpa": qnh_value,
                    "iterations": iteration_records,
                }
            )
        issues.extend(final.issues)
        if not converged:
            issues.append(
                Issue(
                    code="ITERATION_NOT_CONVERGED",
                    severity=IssueSeverity.WARNING,
                    message="5回以内に代表時刻が30秒未満へ収束しませんでした。",
                    acknowledgement_required=True,
                )
            )
        derived_points = final.derived_points
        issues.extend(self._flight_phase_sequence_issues(geometries))
        issues.extend(self._calculation_output_completeness_issues(final.sections))
        issues.extend(
            self._missing_derived_phase_point_issues(
                geometries,
                derived_points,
            )
        )

        if selected_run_id is not None:
            final_requirement = self.forecast_service.build_final_requirement(
                working,
                tuple(final.representative_times.values()),
            )
            run_status = provider.inspect_run_status(selected_run_id, final_requirement)
            if not run_status.selected_run_covers_requirement:
                issues.append(
                    self._blocker(
                        "FORECAST_RUN_OUT_OF_COVERAGE",
                        "最終経路時刻を選択済みForecast Runが覆いません。再選択が必要です。",
                    )
                )

        fuel_plan = build_fuel_plan(
            working.total_usable_fuel_gal,
            final.phases,
            final.section_fuels,
            working.tgl_count,
        )
        if fuel_plan.extra_gal is not None and fuel_plan.extra_gal < 0:
            issues.append(
                self._blocker("INSUFFICIENT_FUEL", "搭載燃料が最小必要燃料を下回ります。")
            )
        issues = self._deduplicate_issues(issues)
        project_status = self._status(working, issues)
        return CalculationOutcome(
            project_id=working.id,
            selected_forecast_run_id=selected_run_id,
            qnh_hpa=qnh_value,
            sections=final.sections,
            derived_points=derived_points,
            fuel_plan=fuel_plan,
            issues=issues,
            iterations=iteration_records,
            converged=converged,
            status=project_status,
            policy_version=self.policies.version,
            performance_table_version=self.performance.manifest.source_revision,
        )

    def _build_geometry(self, project: Project, issues: list[Issue]) -> list[_Geometry]:
        if len(project.route_nodes) < 2 or not project.sections:
            issues.append(self._blocker("ROUTE_INCOMPLETE", "経路とSectionを確定してください。"))
            return []
        ordered_nodes = project.ordered_nodes()
        ordered_sections = project.ordered_sections()
        if (
            len(ordered_sections) != len(ordered_nodes) - 1
            or len({node.sequence for node in ordered_nodes}) != len(ordered_nodes)
            or len({section.sequence for section in ordered_sections})
            != len(ordered_sections)
            or any(
                section.from_node_id != start.id
                or section.to_node_id != end.id
                for section, (start, end) in zip(
                    ordered_sections,
                    zip(ordered_nodes, ordered_nodes[1:], strict=False),
                    strict=False,
                )
            )
        ):
            issues.append(
                self._blocker(
                    "ROUTE_INCOMPLETE",
                    "Route NodeとSectionが先頭から末尾まで一続きになっていません。",
                )
            )
            return []
        nodes = {node.id: node for node in ordered_nodes}
        geometries: list[_Geometry] = []
        for section in ordered_sections:
            try:
                start, end = nodes[section.from_node_id], nodes[section.to_node_id]
            except KeyError:
                issues.append(
                    self._blocker("ROUTE_INCOMPLETE", "Section端点が存在しません.", section.id)
                )
                continue
            leg = geodesic_leg(
                start.latitude_deg,
                start.longitude_deg,
                end.latitude_deg,
                end.longitude_deg,
            )
            adopted_distance = (
                start.manual_distance_nm
                if start.manual_distance_nm is not None
                else leg.distance_nm
            )
            if (
                not isfinite(leg.distance_nm)
                or leg.distance_nm <= 1e-9
                or not isfinite(adopted_distance)
                or adopted_distance <= 0
            ):
                issues.append(
                    self._blocker(
                        "ROUTE_INCOMPLETE",
                        "同一座標または無効な距離のRoute Legは計算できません。",
                        section.id,
                    )
                )
                return []
            geometries.append(
                _Geometry(
                    section,
                    start,
                    end,
                    leg,
                    start.manual_true_course_deg
                    if start.manual_true_course_deg is not None
                    else leg.initial_true_course_deg,
                    start.manual_distance_nm
                    if start.manual_distance_nm is not None
                    else leg.distance_nm,
                )
            )
        return geometries

    def _select_and_prepare_run(
        self,
        project: Project,
        provider: WeatherProvider,
        requirement: ForecastRequirement,
        issues: list[Issue],
    ) -> str | None:
        try:
            if project.selected_forecast_run_id is None:
                run = provider.resolve_run(requirement)
                selected_run_id = run.id
            else:
                status = provider.inspect_run_status(
                    project.selected_forecast_run_id,
                    requirement,
                )
                selected_run_id = project.selected_forecast_run_id
                if not status.selected_run_covers_requirement:
                    issues.append(
                        self._blocker(
                            "FORECAST_RUN_OUT_OF_COVERAGE",
                            "保存済みForecast Runが必要時間帯を覆いません。",
                        )
                    )
                    return None
                if status.update_available:
                    issues.append(
                        Issue(
                            code="FORECAST_UPDATE_AVAILABLE",
                            severity=IssueSeverity.WARNING,
                            message=(
                                "新しい互換Forecast Runがあります。"
                                "保存済みRunは変更していません。"
                            ),
                        )
                    )
            prepared = provider.prepare_run(selected_run_id, requirement)
            self.last_forecast_metadata = prepared.metadata
            return selected_run_id
        except Exception as error:
            issues.append(self._blocker("FORECAST_PREPARE_FAILED", str(error)))
            return None

    def _weather_requests(
        self,
        project: Project,
        departure: Airport,
        destination: Airport,
        geometries: list[_Geometry],
        previous_times: dict[str, datetime],
    ) -> list[WeatherRequest]:
        requests: list[WeatherRequest] = []
        if project.manual_qnh_hpa is None:
            requests.append(
                WeatherRequest(
                    request_id="project:qnh",
                    kind=WeatherRequestKind.ESTIMATED_QNH,
                    latitude_deg=departure.latitude_deg,
                    longitude_deg=departure.longitude_deg,
                    valid_time_utc=project.planned_departure_time_jst,
                    elevation_ft_msl=departure.elevation_ft_msl,
                    metadata={
                        "station_icao": departure.icao,
                        "source_rule": "AUTOMATIC_QNH_PROVIDER",
                        "airport_id": departure.id,
                        "airport_elevation_ft_msl": (
                            departure.elevation_ft_msl
                        ),
                    },
                )
            )
        elapsed = 0.0
        for index, geometry in enumerate(geometries):
            default_seconds = geometry.distance_nm / (
                geometry.section.manual_tas_kt or ForecastService.estimate_speed_kt
            ) * 3600.0
            valid_time = previous_times.get(
                str(geometry.section.id),
                project.planned_departure_time_jst
                + timedelta(seconds=elapsed + default_seconds / 2),
            )
            elapsed += default_seconds + geometry.section.loss_time_seconds
            altitude_ft_msl, altitude_metadata = (
                self._weather_request_representative_altitude(
                    index,
                    geometries,
                    departure,
                    destination,
                )
            )
            requests.append(
                WeatherRequest(
                    request_id=f"section:{geometry.section.id}:aloft",
                    kind=WeatherRequestKind.ALOFT,
                    latitude_deg=geometry.geodesic.midpoint_latitude_deg,
                    longitude_deg=geometry.geodesic.midpoint_longitude_deg,
                    valid_time_utc=valid_time,
                    altitude_ft_msl=altitude_ft_msl,
                    metadata=altitude_metadata,
                )
            )
        return requests

    @classmethod
    def _weather_request_representative_altitude(
        cls,
        index: int,
        geometries: list[_Geometry],
        departure: Airport,
        destination: Airport,
    ) -> tuple[float, dict[str, Any]]:
        section = geometries[index].section
        phase = section.phase
        source_rule = "CAC_REV19_8-(3)_5_AND_6"
        if phase == FlightPhase.CRUISE:
            altitude = float(section.planned_altitude_ft_msl)
            return altitude, {
                "source_rule": source_rule,
                "phase": phase.value,
                "representative_altitude_policy": (
                    "SECTION_PLANNED_CRUISE_ALTITUDE_MSL"
                ),
                "representative_altitude_ft_msl": altitude,
                "altitude_basis": "CRUISE_ALTITUDE",
            }

        if phase == FlightPhase.CLIMB:
            lower_altitude = float(departure.elevation_ft_msl)
            upper_altitude = float(section.planned_altitude_ft_msl)
            altitude_basis = (
                "DEPARTURE_AIRPORT_ELEVATION_AND_CRUISE_ALTITUDE"
            )
        elif phase == FlightPhase.DESCENT:
            lower_altitude = float(
                cls._descent_target_altitude(
                    index,
                    geometries,
                    destination,
                )
            )
            upper_altitude = float(section.planned_altitude_ft_msl)
            altitude_basis = (
                "CRUISE_ALTITUDE_AND_VISUAL_REPORTING_POINT_ALTITUDE"
            )
        else:
            lower_altitude = float(destination.elevation_ft_msl)
            upper_altitude = float(section.planned_altitude_ft_msl)
            altitude_basis = (
                "VISUAL_REPORTING_POINT_ALTITUDE_AND_DESTINATION_ELEVATION"
            )
        representative_altitude = (
            lower_altitude + upper_altitude
        ) / 2.0
        return representative_altitude, {
            "source_rule": source_rule,
            "phase": phase.value,
            "representative_altitude_policy": (
                "ARITHMETIC_MEAN_OF_ENDPOINT_ALTITUDES_MSL"
            ),
            "lower_altitude_ft_msl": lower_altitude,
            "upper_altitude_ft_msl": upper_altitude,
            "representative_altitude_ft_msl": representative_altitude,
            "altitude_basis": altitude_basis,
        }

    def _query_weather(
        self,
        provider: WeatherProvider,
        selected_run_id: str | None,
        requests: list[WeatherRequest],
        issues: list[Issue],
    ) -> list[WeatherResult]:
        self.last_weather_requests.extend(requests)
        if selected_run_id is None:
            return []
        try:
            results = list(provider.query_batch(selected_run_id, requests))
        except Exception as error:
            issues.append(self._blocker("WEATHER_QUERY_FAILED", str(error)))
            return []
        if {item.request_id for item in results} != {item.request_id for item in requests}:
            issues.append(
                self._blocker(
                    "WEATHER_BATCH_MISMATCH",
                    "WeatherProviderのrequest ID対応が一致しません。",
                )
            )
            return []
        requests_by_id = {request.request_id: request for request in requests}
        results = [
            result.model_copy(
                update={
                    "metadata": result.metadata
                    | {
                        "request_metadata": requests_by_id[
                            result.request_id
                        ].metadata
                    }
                }
            )
            for result in results
        ]
        self.last_weather_results.extend(results)
        return results

    @staticmethod
    def _adopt_qnh(project: Project, results: list[WeatherResult]) -> AdoptedValue[float]:
        result = next((item for item in results if item.request_id == "project:qnh"), None)
        automatic = None
        metadata: dict[str, Any] = {}
        warnings: tuple[str, ...] = ()
        if result is not None:
            metadata = result.metadata | {"values": result.values}
            values_label = result.values.get("label")
            metadata_label = result.metadata.get("label")
            label = (
                values_label
                if isinstance(values_label, str) and values_label.strip()
                else metadata_label
            )
            if isinstance(label, str) and label.strip():
                metadata["label"] = label.strip()
            warnings = result.warnings
            if result.availability == Availability.AVAILABLE:
                value = result.values.get("qnh_hpa")
                automatic = float(value) if isinstance(value, (int, float)) else None
        return _manual_or_automatic(
            automatic,
            project.manual_qnh_hpa,
            metadata=metadata,
            warnings=warnings,
        )

    def _build_leg_environments(
        self,
        geometries: list[_Geometry],
        weather_by_id: dict[str, WeatherResult],
        qnh_hpa: float,
        issues: list[Issue],
    ) -> list[_LegEnvironment]:
        environments: list[_LegEnvironment] = []
        for geometry in geometries:
            section = geometry.section
            if section.safe_enroute_altitude_ft_msl is None:
                issues.append(
                    self._blocker(
                        "SAFE_ENROUTE_ALTITUDE_REQUIRED",
                        (
                            "安全高度（SEA）が未入力です。予定経路の両側3 nm以内の"
                            "障害物を確認し、規程に従って100 ft単位で入力してください。"
                        ),
                        section.id,
                        segment_sequence=section.sequence,
                    )
                )
            elif (
                section.planned_altitude_ft_msl
                < section.safe_enroute_altitude_ft_msl
            ):
                issues.append(
                    self._blocker(
                        "PLANNED_ALTITUDE_BELOW_SAFE_ENROUTE",
                        "計画高度が入力済み安全高度（SEA）を下回っています。",
                        section.id,
                        segment_sequence=section.sequence,
                    )
                )
            weather = weather_by_id.get(f"section:{section.id}:aloft")
            wind_direction, wind_speed, temperature, metadata, warnings = (
                self._section_weather(section, weather)
            )
            if temperature is None:
                issues.append(
                    self._blocker(
                        "TEMPERATURE_UNAVAILABLE",
                        "気温を取得できません。手動入力が必要です。",
                        section.id,
                    )
                )
            if (
                section.phase != FlightPhase.VISUAL_ARRIVAL
                and (
                    wind_speed is None
                    or (wind_speed > 0 and wind_direction is None)
                )
            ):
                issues.append(
                    self._blocker(
                        "WIND_UNAVAILABLE",
                        "風を取得できません。手動入力が必要です。",
                        section.id,
                    )
                )
            exact_pa = pressure_altitude_exact_ft(
                section.planned_altitude_ft_msl,
                qnh_hpa,
            )
            environments.append(
                _LegEnvironment(
                    geometry=geometry,
                    weather=weather,
                    wind_direction_deg_from=wind_direction,
                    wind_speed_kt=wind_speed,
                    temperature_c=temperature,
                    weather_metadata=metadata,
                    weather_warnings=warnings,
                    pressure_altitude_exact_ft=exact_pa,
                    pressure_altitude_planning_ft=pressure_altitude_planning_ft(
                        exact_pa,
                        self.policies.pa_500_policy,
                    ),
                )
            )
        return environments

    @staticmethod
    def _route_leg_offsets(
        geometries: list[_Geometry],
    ) -> list[tuple[float, float]]:
        offsets: list[tuple[float, float]] = []
        cumulative = 0.0
        for geometry in geometries:
            start = cumulative
            cumulative += geometry.distance_nm
            offsets.append((start, cumulative))
        return offsets

    def _distance_after_duration(
        self,
        environments: list[_LegEnvironment],
        duration_seconds: float,
        tas_kt: float,
        issues: list[Issue],
        section_id: UUID,
    ) -> _RouteTraversal:
        remaining_seconds = duration_seconds
        route_distance = 0.0
        for environment in environments:
            wind_speed = environment.wind_speed_kt
            if wind_speed is None:
                return _RouteTraversal(None)
            try:
                solution = solve_wind_triangle(
                    environment.geometry.true_course_deg,
                    tas_kt,
                    environment.wind_direction_deg_from,
                    wind_speed,
                )
            except WindTriangleError as error:
                issues.append(
                    self._blocker(
                        "WIND_TRIANGLE_FAILED",
                        str(error),
                        section_id,
                    )
                )
                return _RouteTraversal(None)
            full_leg_seconds = (
                environment.geometry.distance_nm
                / solution.ground_speed_kt
                * 3600.0
            )
            if remaining_seconds <= full_leg_seconds + 1e-9:
                return _RouteTraversal(
                    route_distance
                    + solution.ground_speed_kt * remaining_seconds / 3600.0
                )
            remaining_seconds -= full_leg_seconds
            route_distance += environment.geometry.distance_nm
        return _RouteTraversal(None, route_exhausted=True)

    def _build_climb_plan(
        self,
        departure: Airport,
        environments: list[_LegEnvironment],
        qnh_hpa: float,
        climb_calculator: ClimbCalculator,
        unique_weights: list[float],
        performance_usable: bool,
        issues: list[Issue],
    ) -> _ClimbPlan | None:
        climb_environment = next(
            (
                environment
                for environment in environments
                if environment.geometry.section.phase == FlightPhase.CLIMB
            ),
            None,
        )
        if climb_environment is None or not performance_usable:
            return None
        section = climb_environment.geometry.section
        temperature = climb_environment.temperature_c
        if temperature is None:
            return None
        if len(unique_weights) != 1:
            issues.append(
                self._blocker(
                    "CLIMB_WEIGHT_UNRESOLVED",
                    "上昇表に複数重量があり、採用重量を確定できません。",
                    section.id,
                )
            )
            return None
        try:
            departure_pa = pressure_altitude_exact_ft(
                departure.elevation_ft_msl,
                qnh_hpa,
            )
            climb = climb_calculator.calculate(
                departure_pa,
                climb_environment.pressure_altitude_exact_ft,
                temperature,
                unique_weights[0],
            )
        except ClimbPerformanceError as error:
            issues.append(
                self._blocker(
                    "CLIMB_PERFORMANCE_UNAVAILABLE",
                    str(error),
                    section.id,
                )
            )
            return None
        representative_pressure_altitude_ft = (
            departure_pa + climb_environment.pressure_altitude_exact_ft
        ) / 2.0
        if section.manual_tas_kt is None:
            tas_kt = tas_from_cas(
                111.0,
                representative_pressure_altitude_ft,
                temperature,
            )
            tas_method = (
                "CAC_REV19_8-(3)_5_(1)_CAS_111_AT_"
                "REPRESENTATIVE_PRESSURE_ALTITUDE"
            )
            cas_kt: float | None = 111.0
        else:
            tas_kt = section.manual_tas_kt
            tas_method = "MANUAL_OVERRIDE"
            cas_kt = None
        duration_seconds = climb.time_min * 60.0
        traversal = self._distance_after_duration(
            environments,
            duration_seconds,
            tas_kt,
            issues,
            section.id,
        )
        route_end_distance = traversal.distance_nm
        if route_end_distance is None:
            if traversal.route_exhausted:
                issues.append(
                    self._blocker(
                        "RCA_OUTSIDE_ROUTE",
                        "上昇完了までの飛行距離が計画経路端を越えます。",
                        section.id,
                    )
                )
            return None
        for warning in climb.warnings:
            issues.append(
                Issue(
                    code=warning,
                    severity=IssueSeverity.WARNING,
                    message="上昇表の高度軸を表端から500 ft以内で外挿しました。",
                    section_id=section.id,
                )
            )
        return _ClimbPlan(
            source_section_id=section.id,
            duration_seconds=duration_seconds,
            fuel_gal=climb.fuel_gal,
            tas_kt=tas_kt,
            route_end_distance_nm=route_end_distance,
            metadata={
                "type": "climb",
                "weight_lb": unique_weights[0],
                "table_distance_nm": climb.distance_nm,
                "route_distance_nm": route_end_distance,
                "planned_duration_seconds": duration_seconds,
                "planned_fuel_gal": climb.fuel_gal,
                "representative_tas_kt": tas_kt,
                "representative_pressure_altitude_ft": (
                    representative_pressure_altitude_ft
                ),
                "midpoint_temperature_c": temperature,
                "cas_kt": cas_kt,
                "tas_method": tas_method,
                "poh_table_distance_reference_nm": climb.distance_nm,
                "poh_table_distance_usage": "REFERENCE_ONLY",
                "temperature_policy": climb.temperature_policy,
                "representative_altitude_ft": (
                    climb.representative_altitude_ft
                ),
                "representative_isa_temperature_c": (
                    climb.representative_isa_temperature_c
                ),
                "temperature_delta_above_standard_c": (
                    climb.temperature_delta_above_standard_c
                ),
                "temperature_adjustment_factor": (
                    climb.temperature_adjustment_factor
                ),
                "warnings": climb.warnings,
                "boundary_method": "time-and-leg-specific-wind",
            },
        )

    def _preview_last_cruise_cas(
        self,
        environments: list[_LegEnvironment],
        end_index: int,
        cruise_policy: CruisePerformanceSelectionPolicy,
    ) -> float | None:
        last_cas: float | None = None
        for environment in environments[: end_index + 1]:
            if environment.geometry.section.phase != FlightPhase.CRUISE:
                continue
            temperature = environment.temperature_c
            wind_speed = environment.wind_speed_kt
            if temperature is None or wind_speed is None:
                continue
            section = environment.geometry.section
            tas = section.manual_tas_kt
            if tas is None:
                try:
                    selected = cruise_policy.select(
                        environment.pressure_altitude_planning_ft,
                        temperature
                        - isa_temperature_c(
                            environment.pressure_altitude_planning_ft
                        ),
                        environment.geometry.distance_nm,
                        environment.geometry.true_course_deg,
                        environment.wind_direction_deg_from,
                        wind_speed,
                    )
                except CruisePerformanceError:
                    continue
                tas = selected.row.ktas
            last_cas = cas_from_tas(
                tas,
                environment.pressure_altitude_exact_ft,
                temperature,
            )
        return last_cas

    def _build_descent_plan(
        self,
        environments: list[_LegEnvironment],
        geometries: list[_Geometry],
        destination: Airport,
        cruise_policy: CruisePerformanceSelectionPolicy,
        issues: list[Issue],
    ) -> _DescentPlan | None:
        descent_index = next(
            (
                index
                for index, environment in enumerate(environments)
                if environment.geometry.section.phase == FlightPhase.DESCENT
            ),
            None,
        )
        if descent_index is None:
            return None
        descent_environment = environments[descent_index]
        section = descent_environment.geometry.section
        target_altitude = self._descent_target_altitude(
            descent_index,
            geometries,
            destination,
        )
        altitude_difference = section.planned_altitude_ft_msl - target_altitude
        if altitude_difference <= 0:
            issues.append(
                self._blocker(
                    "DESCENT_ALTITUDE_INVALID",
                    "降下開始高度は到着側高度より高く設定してください。",
                    section.id,
                )
            )
            return None
        duration_seconds = altitude_difference / 500.0 * 60.0
        cruise_cas = self._preview_last_cruise_cas(
            environments,
            descent_index,
            cruise_policy,
        )
        if section.manual_tas_kt is None and cruise_cas is None:
            issues.append(
                self._blocker(
                    "DESCENT_TAS_UNAVAILABLE",
                    "降下TASの基準となる直前巡航CASを確定できません。",
                    section.id,
                )
            )
            return None

        offsets = self._route_leg_offsets(geometries)
        route_end_distance = offsets[descent_index][1]
        remaining_seconds = duration_seconds
        route_start_distance = route_end_distance
        for index in range(descent_index, -1, -1):
            environment = environments[index]
            temperature = environment.temperature_c
            wind_speed = environment.wind_speed_kt
            if temperature is None or wind_speed is None:
                return None
            tas = section.manual_tas_kt
            if tas is None and cruise_cas is not None:
                tas = tas_from_cas(
                    cruise_cas,
                    environment.pressure_altitude_exact_ft,
                    temperature,
                )
            if tas is None:
                return None
            try:
                solution = solve_wind_triangle(
                    environment.geometry.true_course_deg,
                    tas,
                    environment.wind_direction_deg_from,
                    wind_speed,
                )
            except WindTriangleError as error:
                issues.append(
                    self._blocker(
                        "WIND_TRIANGLE_FAILED",
                        str(error),
                        section.id,
                    )
                )
                return None
            full_leg_seconds = (
                environment.geometry.distance_nm
                / solution.ground_speed_kt
                * 3600.0
            )
            if remaining_seconds <= full_leg_seconds + 1e-9:
                route_start_distance -= (
                    solution.ground_speed_kt * remaining_seconds / 3600.0
                )
                remaining_seconds = 0.0
                break
            remaining_seconds -= full_leg_seconds
            route_start_distance -= environment.geometry.distance_nm
        if remaining_seconds > 1e-6:
            issues.append(
                self._blocker(
                    "EOC_OUTSIDE_ROUTE",
                    "必要な降下距離が降下Section以前の計画経路を越えます。",
                    section.id,
                )
            )
            return None
        if cruise_cas is None:
            cruise_cas = cas_from_tas(
                section.manual_tas_kt or 0.0,
                descent_environment.pressure_altitude_exact_ft,
                descent_environment.temperature_c or 0.0,
            )
        return _DescentPlan(
            source_section_id=section.id,
            duration_seconds=duration_seconds,
            route_start_distance_nm=route_start_distance,
            route_end_distance_nm=route_end_distance,
            cruise_cas_kt=cruise_cas,
            metadata={
                "type": "descent",
                "descent_rate_fpm": 500.0,
                "target_altitude_ft_msl": target_altitude,
                "planned_duration_seconds": duration_seconds,
                "cruise_cas_kt": cruise_cas,
                "fuel_flow_gph": 12.0,
                "boundary_method": "time-and-leg-specific-wind",
            },
        )

    def _build_phase_segmentation(
        self,
        geometries: list[_Geometry],
        climb_plan: _ClimbPlan | None,
        descent_plan: _DescentPlan | None,
        issues: list[Issue],
    ) -> PhaseSegmentation:
        physical_legs = tuple(
            PhysicalRouteLeg(
                source_index=index,
                source_id=geometry.section.id,
                start_name=geometry.start.name,
                start_latitude_deg=geometry.start.latitude_deg,
                start_longitude_deg=geometry.start.longitude_deg,
                end_name=geometry.end.name,
                end_latitude_deg=geometry.end.latitude_deg,
                end_longitude_deg=geometry.end.longitude_deg,
                adopted_distance_nm=geometry.distance_nm,
            )
            for index, geometry in enumerate(geometries)
        )
        climb_required = any(
            geometry.section.phase == FlightPhase.CLIMB
            for geometry in geometries
        )
        descent_required = any(
            geometry.section.phase == FlightPhase.DESCENT
            for geometry in geometries
        )
        visual_source_id = (
            geometries[-1].section.id
            if geometries
            and geometries[-1].section.phase == FlightPhase.VISUAL_ARRIVAL
            else None
        )

        def source_phase_fallback() -> PhaseSegmentation:
            try:
                fallback = split_route_into_phase_segments(
                    physical_legs,
                    visual_leg_source_id=visual_source_id,
                )
            except PhaseSegmentationError as error:
                issues.append(
                    self._blocker(
                        "ROUTE_SEGMENTATION_INPUT_INVALID",
                        f"経路を安全な計算区間へ変換できません: {error}",
                    )
                )
                return PhaseSegmentation(
                    segments=(),
                    total_distance_nm=sum(
                        geometry.distance_nm for geometry in geometries
                    ),
                )
            return fallback.__class__(
                segments=tuple(
                    replace(
                        segment,
                        phase=geometries[segment.source_index].section.phase,
                    )
                    for segment in fallback.segments
                ),
                total_distance_nm=fallback.total_distance_nm,
            )

        if (climb_required and climb_plan is None) or (
            descent_required and descent_plan is None
        ):
            return source_phase_fallback()
        try:
            return split_route_into_phase_segments(
                physical_legs,
                rca_distance_nm=(
                    None
                    if climb_plan is None
                    else climb_plan.route_end_distance_nm
                ),
                eoc_distance_nm=(
                    None
                    if descent_plan is None
                    else descent_plan.route_start_distance_nm
                ),
                descent_end_distance_nm=(
                    None
                    if descent_plan is None
                    else descent_plan.route_end_distance_nm
                ),
                visual_leg_source_id=visual_source_id,
            )
        except PhaseSegmentationError as error:
            issues.append(
                self._blocker(
                    "PHASE_SEGMENTATION_FAILED",
                    f"RCA/EOCによる経路分割に失敗しました: {error}",
                )
            )
            return source_phase_fallback()

    @staticmethod
    def _derived_points_from_segmentation(
        segmentation: PhaseSegmentation,
        boundary_times: dict[float, datetime],
    ) -> list[DerivedRoutePoint]:
        points: list[DerivedRoutePoint] = []
        if segmentation.rca_point is not None:
            containing = next(
                (
                    segment
                    for segment in segmentation.segments
                    if abs(
                        segment.end_distance_nm
                        - segmentation.rca_point.along_route_distance_nm
                    )
                    <= 1e-9
                ),
                None,
            )
            if containing is not None and isinstance(containing.source_id, UUID):
                points.append(
                    DerivedRoutePoint(
                        type=DerivedPointType.RCA,
                        section_id=containing.source_id,
                        latitude_deg=segmentation.rca_point.latitude_deg,
                        longitude_deg=segmentation.rca_point.longitude_deg,
                        along_route_distance_nm=(
                            segmentation.rca_point.along_route_distance_nm
                        ),
                        estimated_time_utc=boundary_times.get(
                            segmentation.rca_point.along_route_distance_nm
                        ),
                    )
                )
        if segmentation.eoc_point is not None:
            containing = next(
                (
                    segment
                    for segment in segmentation.segments
                    if abs(
                        segment.start_distance_nm
                        - segmentation.eoc_point.along_route_distance_nm
                    )
                    <= 1e-9
                ),
                None,
            )
            if containing is not None and isinstance(containing.source_id, UUID):
                points.append(
                    DerivedRoutePoint(
                        type=DerivedPointType.EOC,
                        section_id=containing.source_id,
                        latitude_deg=segmentation.eoc_point.latitude_deg,
                        longitude_deg=segmentation.eoc_point.longitude_deg,
                        along_route_distance_nm=(
                            segmentation.eoc_point.along_route_distance_nm
                        ),
                        estimated_time_utc=boundary_times.get(
                            segmentation.eoc_point.along_route_distance_nm
                        ),
                    )
                )
        return points

    def _calculate_iteration(
        self,
        project: Project,
        departure: Airport,
        destination: Airport,
        geometries: list[_Geometry],
        weather_results: list[WeatherResult],
        qnh_hpa: float,
    ) -> _IterationResult:
        issues: list[Issue] = []
        weather_by_id = {item.request_id: item for item in weather_results}
        performance_usable = True
        try:
            self.performance.require_verified()
        except PerformanceDataError as error:
            performance_usable = False
            issues.append(self._blocker("PERFORMANCE_DATA_UNAVAILABLE", str(error)))
        climb_calculator = ClimbCalculator(
            self.performance.climb_rows,
            self.performance.manifest.climb_temperature_policy,
        )
        cruise_policy = CruisePerformanceSelectionPolicy(self.performance.cruise_rows)
        unique_weights = sorted({row.weight_lb for row in self.performance.climb_rows})
        environments = self._build_leg_environments(
            geometries,
            weather_by_id,
            qnh_hpa,
            issues,
        )
        climb_plan = self._build_climb_plan(
            departure,
            environments,
            qnh_hpa,
            climb_calculator,
            unique_weights,
            performance_usable,
            issues,
        )
        descent_plan = self._build_descent_plan(
            environments,
            geometries,
            destination,
            cruise_policy,
            issues,
        )
        segmentation = self._build_phase_segmentation(
            geometries,
            climb_plan,
            descent_plan,
            issues,
        )

        sections: list[SectionResult] = []
        section_fuels: list[float | None] = []
        phases: list[FlightPhase] = []
        cumulative_distance = 0.0
        cumulative_seconds: float | None = 0.0
        departure_utc = project.planned_departure_time_jst.astimezone(timezone.utc)
        boundary_times: dict[float, datetime] = {0.0: departure_utc}
        source_time_bounds: dict[str, tuple[float, float]] = {}
        offsets = self._route_leg_offsets(geometries)
        climb_source = (
            next(
                (
                    geometry.section
                    for geometry in geometries
                    if climb_plan is not None
                    and geometry.section.id == climb_plan.source_section_id
                ),
                None,
            )
            if climb_plan is not None
            else None
        )
        descent_source = (
            next(
                (
                    geometry.section
                    for geometry in geometries
                    if descent_plan is not None
                    and geometry.section.id == descent_plan.source_section_id
                ),
                None,
            )
            if descent_plan is not None
            else None
        )

        for segment in segmentation.segments:
            environment = environments[segment.source_index]
            geometry = environment.geometry
            section = geometry.section
            weather = environment.weather
            segment_geometry = geodesic_leg(
                segment.start.latitude_deg,
                segment.start.longitude_deg,
                segment.end.latitude_deg,
                segment.end.longitude_deg,
            )
            manual_course = geometry.start.manual_true_course_deg
            course_value = _manual_or_automatic(
                geometry.geodesic.initial_true_course_deg,
                manual_course,
                metadata={
                    "method": "source physical leg WGS84 initial bearing",
                    "phase_segment": True,
                    "source_section_id": str(section.id),
                },
                warnings=("MANUAL_TRUE_COURSE",) if manual_course is not None else (),
            )
            adopted_course = course_value.adopted()
            source_manual_distance = geometry.start.manual_distance_nm
            distance_value = _automatic(
                segment.distance_nm,
                ValueState.AUTO,
                metadata={
                    "method": (
                        "distributed from source manual distance"
                        if source_manual_distance is not None
                        else "WGS84 geodesic phase segment"
                    ),
                    "source_section_id": str(section.id),
                    "source_manual_distance_nm": source_manual_distance,
                    "geodesic_segment_distance_nm": segment_geometry.distance_nm,
                    "global_start_distance_nm": segment.start_distance_nm,
                    "global_end_distance_nm": segment.end_distance_nm,
                },
                warnings=("DISTRIBUTED_FROM_MANUAL_SOURCE_DISTANCE",)
                if source_manual_distance is not None
                else (),
            )
            adopted_distance = distance_value.adopted()
            magnetic_course = (
                None
                if adopted_course is None
                else (adopted_course - project.default_variation_deg_east) % 360
            )

            wind_direction = environment.wind_direction_deg_from
            wind_speed = environment.wind_speed_kt
            temperature = environment.temperature_c
            exact_pa = environment.pressure_altitude_exact_ft
            planning_pa = environment.pressure_altitude_planning_ft
            tas: float | None = None
            manual_tas: float | None = None
            cas: float | None = None
            gph: float | None = None
            performance_metadata: dict[str, Any] = {
                "phase_segment": {
                    "sequence": segment.sequence,
                    "source_section_id": str(section.id),
                    "global_start_distance_nm": segment.start_distance_nm,
                    "global_end_distance_nm": segment.end_distance_nm,
                }
            }
            tas_state = ValueState.UNAVAILABLE

            if segment.phase == FlightPhase.CLIMB:
                if climb_plan is not None:
                    manual_tas = None if climb_source is None else climb_source.manual_tas_kt
                    tas = climb_plan.tas_kt
                    tas_state = (
                        ValueState.MANUAL_OVERRIDE
                        if manual_tas is not None
                        else ValueState.FIXED_RULE
                    )
                    if manual_tas is None:
                        cas = 111.0
                    performance_metadata.update(climb_plan.metadata)
                else:
                    manual_tas = section.manual_tas_kt
                    tas = manual_tas
                    tas_state = (
                        ValueState.MANUAL_OVERRIDE
                        if manual_tas is not None
                        else ValueState.UNAVAILABLE
                    )
            elif segment.phase == FlightPhase.CRUISE:
                manual_tas = section.manual_tas_kt
                tas = manual_tas
                tas_state = (
                    ValueState.MANUAL_OVERRIDE
                    if manual_tas is not None
                    else ValueState.UNAVAILABLE
                )
                if (
                    performance_usable
                    and temperature is not None
                    and wind_speed is not None
                    and adopted_distance is not None
                ):
                    try:
                        selected = cruise_policy.select(
                            planning_pa,
                            temperature - isa_temperature_c(planning_pa),
                            adopted_distance,
                            adopted_course or 0.0,
                            wind_direction,
                            wind_speed,
                        )
                        if tas is None:
                            tas = selected.row.ktas
                            tas_state = ValueState.PERFORMANCE_TABLE
                        gph = selected.row.gph
                        performance_metadata.update(
                            {
                                "type": "cruise",
                                "selected_cell": selected.row.model_dump(),
                                "reason": selected.reason,
                                "warnings": selected.warnings,
                            }
                        )
                        for warning in selected.warnings:
                            issues.append(
                                Issue(
                                    code=warning,
                                    severity=IssueSeverity.WARNING,
                                    message="65%に最も近い表セルを採用しました。",
                                    section_id=section.id,
                                    segment_sequence=segment.sequence,
                                )
                            )
                    except CruisePerformanceError as error:
                        issues.append(
                            self._blocker(
                                "CRUISE_PERFORMANCE_UNAVAILABLE",
                                str(error),
                                section.id,
                                segment_sequence=segment.sequence,
                            )
                        )
            elif segment.phase == FlightPhase.DESCENT:
                if descent_plan is not None:
                    manual_tas = (
                        None if descent_source is None else descent_source.manual_tas_kt
                    )
                    if manual_tas is not None:
                        tas = manual_tas
                        tas_state = ValueState.MANUAL_OVERRIDE
                    elif temperature is not None:
                        tas = tas_from_cas(
                            descent_plan.cruise_cas_kt,
                            exact_pa,
                            temperature,
                        )
                        tas_state = ValueState.AUTO
                    performance_metadata.update(descent_plan.metadata)
                else:
                    manual_tas = section.manual_tas_kt
                    tas = manual_tas
                    tas_state = (
                        ValueState.MANUAL_OVERRIDE
                        if manual_tas is not None
                        else ValueState.UNAVAILABLE
                    )
            else:
                if temperature is not None:
                    tas = tas_from_cas(121.0, exact_pa, temperature)
                    tas_state = ValueState.FIXED_RULE
                cas = 121.0
                wind_direction = None
                wind_speed = 0.0
                performance_metadata.update(
                    {
                        "type": "visual_arrival",
                        "cas_kt": 121.0,
                        "wind": "CALM_FIXED_RULE",
                        "fuel_flow_gph": 12.0,
                    }
                )

            if tas is not None and temperature is not None and cas is None:
                cas = cas_from_tas(tas, exact_pa, temperature)

            wind_solution = None
            if tas is not None and wind_speed is not None:
                try:
                    wind_solution = solve_wind_triangle(
                        adopted_course or 0.0,
                        tas,
                        wind_direction,
                        wind_speed,
                    )
                except WindTriangleError as error:
                    issues.append(
                        self._blocker(
                            "WIND_TRIANGLE_FAILED",
                            str(error),
                            section.id,
                            segment_sequence=segment.sequence,
                        )
                    )
            ete_seconds = (
                None
                if wind_solution is None or adopted_distance is None
                else adopted_distance / wind_solution.ground_speed_kt * 3600.0
            )
            if (
                segment.phase == FlightPhase.CLIMB
                and climb_plan is not None
                and ete_seconds is not None
            ):
                section_fuel = (
                    climb_plan.fuel_gal
                    * ete_seconds
                    / climb_plan.duration_seconds
                )
            else:
                section_fuel = fuel_for_section(
                    segment.phase,
                    ete_seconds,
                    cruise_gph=gph,
                )

            loss_time = (
                section.loss_time_seconds
                if abs(segment.end_distance_nm - offsets[segment.source_index][1])
                <= 1e-9
                else 0.0
            )
            loss_fuel_gal: float | None = 0.0
            if loss_time > 0:
                if segment.phase == FlightPhase.CLIMB and climb_plan is not None:
                    loss_fuel_gal = (
                        climb_plan.fuel_gal
                        / climb_plan.duration_seconds
                        * loss_time
                    )
                elif segment.phase == FlightPhase.CRUISE and gph is not None:
                    loss_fuel_gal = gph * loss_time / 3600.0
                elif segment.phase in {
                    FlightPhase.DESCENT,
                    FlightPhase.VISUAL_ARRIVAL,
                }:
                    loss_fuel_gal = 12.0 * loss_time / 3600.0
                else:
                    loss_fuel_gal = None
                section_fuel = (
                    None
                    if section_fuel is None or loss_fuel_gal is None
                    else section_fuel + loss_fuel_gal
                )
            performance_metadata["loss_fuel_gal"] = loss_fuel_gal
            cumulative_distance += segment.distance_nm
            segment_start_seconds = cumulative_seconds
            if ete_seconds is not None and cumulative_seconds is not None:
                if segment_start_seconds is None:
                    raise RuntimeError("determined route timing lost its segment start")
                arrival_seconds = segment_start_seconds + ete_seconds
                cumulative_seconds = arrival_seconds + loss_time
                eto = departure_utc + timedelta(seconds=cumulative_seconds)
                boundary_times[segment.end_distance_nm] = (
                    departure_utc + timedelta(seconds=arrival_seconds)
                )
                source_key = str(section.id)
                previous_bounds = source_time_bounds.get(source_key)
                source_time_bounds[source_key] = (
                    segment_start_seconds
                    if previous_bounds is None
                    else previous_bounds[0],
                    arrival_seconds,
                )
            else:
                cumulative_seconds = None
                eto = None

            automatic_wind_direction = (
                None
                if weather is None
                else self._numeric(weather, "wind_direction_deg_from")
            )
            automatic_wind_speed = (
                None if weather is None else self._numeric(weather, "wind_speed_kt")
            )
            manual_wind_direction = section.manual_wind_direction_deg
            manual_wind_speed = section.manual_wind_speed_kt
            wind_state = ValueState.AUTO
            if segment.phase == FlightPhase.VISUAL_ARRIVAL:
                automatic_wind_direction = None
                automatic_wind_speed = 0.0
                manual_wind_direction = None
                manual_wind_speed = None
                wind_state = ValueState.FIXED_RULE

            has_derived_endpoint = bool(segment.start.markers or segment.end.markers)
            sections.append(
                SectionResult(
                    section_id=section.id,
                    sequence=len(sections),
                    phase=segment.phase,
                    segment_label=(
                        f"{segment.start.label}→{segment.end.label}"
                        if has_derived_endpoint
                        else None
                    ),
                    from_name=segment.start.label,
                    to_name=segment.end.label,
                    planned_altitude_ft_msl=_automatic(
                        section.planned_altitude_ft_msl,
                        ValueState.FIXED_RULE,
                        {"source": "PROJECT_INPUT"},
                    ),
                    safe_enroute_altitude_ft_msl=_automatic(
                        section.safe_enroute_altitude_ft_msl,
                        ValueState.FIXED_RULE,
                        {"source": "PROJECT_INPUT"},
                    ),
                    loss_time_seconds=loss_time,
                    pressure_altitude_exact_ft=_automatic(exact_pa),
                    pressure_altitude_planning_ft=_automatic(
                        planning_pa,
                        ValueState.FIXED_RULE,
                        {"policy": self.policies.pa_500_policy},
                    ),
                    true_course_deg=course_value,
                    variation_deg_east=_automatic(
                        project.default_variation_deg_east,
                        ValueState.FIXED_RULE,
                    ),
                    magnetic_course_deg=_automatic(magnetic_course),
                    wind_direction_deg_from=_manual_or_automatic(
                        automatic_wind_direction,
                        manual_wind_direction,
                        state=wind_state,
                        metadata=environment.weather_metadata,
                        warnings=environment.weather_warnings,
                    ),
                    wind_speed_kt=_manual_or_automatic(
                        automatic_wind_speed,
                        manual_wind_speed,
                        state=wind_state,
                        metadata=environment.weather_metadata,
                        warnings=environment.weather_warnings,
                    ),
                    wca_deg=_automatic(
                        None if wind_solution is None else wind_solution.wca_deg
                    ),
                    magnetic_heading_deg=_automatic(
                        None
                        if wind_solution is None or magnetic_course is None
                        else (magnetic_course + wind_solution.wca_deg) % 360
                    ),
                    temperature_c=_manual_or_automatic(
                        None
                        if weather is None
                        else self._numeric(weather, "temperature_c"),
                        section.manual_temperature_c,
                        metadata=environment.weather_metadata,
                    ),
                    cas_kt=_automatic(
                        cas,
                        ValueState.FIXED_RULE
                        if segment.phase == FlightPhase.VISUAL_ARRIVAL
                        else ValueState.AUTO,
                        performance_metadata,
                    ),
                    tas_kt=_manual_or_automatic(
                        tas if manual_tas is None else None,
                        manual_tas,
                        state=tas_state,
                        metadata=performance_metadata,
                    ),
                    ground_speed_kt=_automatic(
                        None if wind_solution is None else wind_solution.ground_speed_kt
                    ),
                    zone_distance_nm=distance_value,
                    cumulative_distance_nm=_automatic(cumulative_distance),
                    zone_ete_seconds=_automatic(ete_seconds),
                    cumulative_ete_seconds=_automatic(cumulative_seconds),
                    eto_utc=_automatic(eto),
                    section_fuel_gal=_automatic(
                        section_fuel,
                        ValueState.PERFORMANCE_TABLE
                        if segment.phase in {FlightPhase.CLIMB, FlightPhase.CRUISE}
                        else ValueState.FIXED_RULE,
                    ),
                    remaining_fuel_gal=_unavailable(),
                    performance_metadata=performance_metadata,
                )
            )
            section_fuels.append(section_fuel)
            phases.append(segment.phase)

        if climb_plan is not None:
            climb_indices = [
                index
                for index, phase in enumerate(phases)
                if phase == FlightPhase.CLIMB
            ]
            climb_values = [section_fuels[index] for index in climb_indices]
            if climb_indices and all(value is not None for value in climb_values):
                correction_index = climb_indices[-1]
                loss_fuel_total = sum(
                    float(
                        sections[index].performance_metadata.get(
                            "loss_fuel_gal",
                            0.0,
                        )
                        or 0.0
                    )
                    for index in climb_indices
                )
                correction = climb_plan.fuel_gal + loss_fuel_total - sum(
                    value for value in climb_values if value is not None
                )
                current_fuel = section_fuels[correction_index]
                if current_fuel is not None:
                    corrected_fuel = current_fuel + correction
                    section_fuels[correction_index] = corrected_fuel
                    sections[correction_index] = sections[
                        correction_index
                    ].model_copy(
                        update={
                            "section_fuel_gal": sections[
                                correction_index
                            ].section_fuel_gal.model_copy(
                                update={"automatic_value": corrected_fuel}
                            )
                        }
                    )

        representative_times = {
            section_id: departure_utc
            + timedelta(seconds=(bounds[0] + bounds[1]) / 2.0)
            for section_id, bounds in source_time_bounds.items()
        }
        derived_points = self._derived_points_from_segmentation(
            segmentation,
            boundary_times,
        )
        if (
            climb_plan is not None
            and geometries
            and climb_plan.route_end_distance_nm > geometries[0].distance_nm + 1e-9
        ):
            issues.append(
                Issue(
                    code="RCA_BEYOND_FIRST_TURN",
                    severity=IssueSeverity.WARNING,
                    message="RCAが最初の変針点を越えます。経路を確認してください。",
                    section_id=climb_plan.source_section_id,
                    acknowledgement_required=True,
                )
            )

        remaining = remaining_fuel(project.total_usable_fuel_gal, section_fuels)
        sections = [
            result.model_copy(
                update={
                    "remaining_fuel_gal": _automatic(value)
                    if value is not None
                    else _unavailable()
                }
            )
            for result, value in zip(sections, remaining, strict=True)
        ]
        return _IterationResult(
            sections,
            self._deduplicate_issues(issues),
            representative_times,
            phases,
            section_fuels,
            derived_points,
        )

    @staticmethod
    def _section_weather(
        section: NavSection,
        weather: WeatherResult | None,
    ) -> tuple[float | None, float | None, float | None, dict[str, Any], tuple[str, ...]]:
        metadata = {} if weather is None else weather.metadata | {"values": weather.values}
        warnings = () if weather is None else weather.warnings
        automatic_direction = None
        automatic_speed = None
        automatic_temperature = None
        if weather is not None and weather.availability == Availability.AVAILABLE:
            automatic_direction = CalculationService._numeric(
                weather,
                "wind_direction_deg_from",
            )
            automatic_speed = CalculationService._numeric(weather, "wind_speed_kt")
            automatic_temperature = CalculationService._numeric(weather, "temperature_c")
        direction = (
            section.manual_wind_direction_deg
            if section.manual_wind_direction_deg is not None
            else automatic_direction
        )
        speed = (
            section.manual_wind_speed_kt
            if section.manual_wind_speed_kt is not None
            else automatic_speed
        )
        temperature = (
            section.manual_temperature_c
            if section.manual_temperature_c is not None
            else automatic_temperature
        )
        if speed == 0:
            direction = None
        return direction, speed, temperature, metadata, warnings

    @staticmethod
    def _numeric(result: WeatherResult, key: str) -> float | None:
        value = result.values.get(key)
        return float(value) if isinstance(value, (int, float)) else None

    @staticmethod
    def _descent_target_altitude(
        index: int,
        geometries: list[_Geometry],
        destination: Airport,
    ) -> float:
        if index + 1 < len(geometries):
            return geometries[index + 1].section.planned_altitude_ft_msl
        return destination.pattern_altitude_ft_msl or destination.elevation_ft_msl

    def _flight_phase_sequence_issues(
        self,
        geometries: list[_Geometry],
    ) -> list[Issue]:
        phase_order = {
            FlightPhase.CLIMB: 0,
            FlightPhase.CRUISE: 1,
            FlightPhase.DESCENT: 2,
            FlightPhase.VISUAL_ARRIVAL: 3,
        }
        issues: list[Issue] = []
        counts: dict[FlightPhase, int] = {}
        previous_order = -1
        for geometry in geometries:
            phase = geometry.section.phase
            counts[phase] = counts.get(phase, 0) + 1
            current_order = phase_order[phase]
            reasons: list[str] = []
            if current_order < previous_order:
                reasons.append("phase order moves backward")
            if phase != FlightPhase.CRUISE and counts[phase] > 1:
                reasons.append(f"{phase.value} appears more than once")
            if reasons:
                issues.append(
                    Issue(
                        code="FLIGHT_PHASE_SEQUENCE_INVALID",
                        severity=IssueSeverity.BLOCKER,
                        message=(
                            "飛行Phaseの順序または出現回数が不正です。"
                            "CLIMB→CRUISE→DESCENT→VISUAL_ARRIVALの順とし、"
                            "CRUISE以外は各1回までです。"
                        ),
                        section_id=geometry.section.id,
                        metadata={
                            "phase": phase.value,
                            "reasons": reasons,
                        },
                    )
                )
            previous_order = max(previous_order, current_order)
        return issues

    def _calculation_output_completeness_issues(
        self,
        sections: list[SectionResult],
    ) -> list[Issue]:
        issues: list[Issue] = []
        for result in sections:
            required: list[tuple[str, AdoptedValue[Any]]] = [
                ("planned_altitude_ft_msl", result.planned_altitude_ft_msl),
                ("pressure_altitude_exact_ft", result.pressure_altitude_exact_ft),
                ("pressure_altitude_planning_ft", result.pressure_altitude_planning_ft),
                ("true_course_deg", result.true_course_deg),
                ("variation_deg_east", result.variation_deg_east),
                ("magnetic_course_deg", result.magnetic_course_deg),
                ("wind_speed_kt", result.wind_speed_kt),
                ("temperature_c", result.temperature_c),
                ("cas_kt", result.cas_kt),
                ("tas_kt", result.tas_kt),
                ("ground_speed_kt", result.ground_speed_kt),
                ("wca_deg", result.wca_deg),
                ("magnetic_heading_deg", result.magnetic_heading_deg),
                ("zone_distance_nm", result.zone_distance_nm),
                ("cumulative_distance_nm", result.cumulative_distance_nm),
                ("zone_ete_seconds", result.zone_ete_seconds),
                ("cumulative_ete_seconds", result.cumulative_ete_seconds),
                ("eto_utc", result.eto_utc),
                ("section_fuel_gal", result.section_fuel_gal),
                ("remaining_fuel_gal", result.remaining_fuel_gal),
            ]
            missing_fields = [
                name
                for name, adopted_value in required
                if adopted_value.adopted() is None
            ]
            wind_speed = result.wind_speed_kt.adopted()
            wind_direction = result.wind_direction_deg_from.adopted()
            if wind_speed is not None and wind_speed > 0 and wind_direction is None:
                missing_fields.append("wind_direction_deg_from")
            if missing_fields:
                issues.append(
                    Issue(
                        code="CALCULATION_OUTPUT_INCOMPLETE",
                        severity=IssueSeverity.BLOCKER,
                        message=(
                            "清書に必要な計算値が未確定です: "
                            + ", ".join(missing_fields)
                        ),
                        section_id=result.section_id,
                        segment_sequence=result.sequence,
                        metadata={
                            "segment_sequence": result.sequence,
                            "missing_fields": missing_fields,
                        },
                    )
                )
        return issues

    def _missing_derived_phase_point_issues(
        self,
        geometries: list[_Geometry],
        points: list[DerivedRoutePoint],
    ) -> list[Issue]:
        present = {point.type for point in points}
        required = (
            (FlightPhase.CLIMB, DerivedPointType.RCA),
            (FlightPhase.DESCENT, DerivedPointType.EOC),
        )
        issues: list[Issue] = []
        for phase, point_type in required:
            geometry = next(
                (item for item in geometries if item.section.phase == phase),
                None,
            )
            if geometry is None or point_type in present:
                continue
            issues.append(
                Issue(
                    code="DERIVED_PHASE_POINT_MISSING",
                    severity=IssueSeverity.BLOCKER,
                    message=(
                        f"{phase.value}を含む計画ですが、"
                        f"{point_type.value}を算出できません。"
                    ),
                    section_id=geometry.section.id,
                    metadata={
                        "phase": phase.value,
                        "required_point": point_type.value,
                    },
                )
            )
        return issues

    @staticmethod
    def _maximum_time_delta(
        previous: dict[str, datetime],
        current: dict[str, datetime],
    ) -> float | None:
        common = previous.keys() & current.keys()
        if not common:
            return None
        return max(abs((current[key] - previous[key]).total_seconds()) for key in common)

    @staticmethod
    def _blocker(
        code: str,
        message: str,
        section_id: UUID | None = None,
        *,
        segment_sequence: int | None = None,
    ) -> Issue:
        return Issue(
            code=code,
            severity=IssueSeverity.BLOCKER,
            message=message,
            section_id=section_id,
            segment_sequence=segment_sequence,
        )

    @staticmethod
    def _deduplicate_issues(issues: list[Issue]) -> list[Issue]:
        output: list[Issue] = []
        seen: set[tuple[str, UUID | None, int | None]] = set()
        for issue in issues:
            key = (issue.code, issue.section_id, issue.segment_sequence)
            if key not in seen:
                seen.add(key)
                output.append(issue)
        return output

    @staticmethod
    def _status(project: Project, issues: list[Issue]) -> ProjectStatus:
        if any(issue.code == "ROUTE_INCOMPLETE" for issue in issues):
            return ProjectStatus.ROUTE_INCOMPLETE
        if any(issue.severity == IssueSeverity.BLOCKER for issue in issues):
            if any(
                issue.code.startswith(("FORECAST", "WEATHER"))
                for issue in issues
            ):
                return ProjectStatus.WEATHER_PENDING
            return ProjectStatus.MANUAL_INPUT_REQUIRED
        unacknowledged = [
            issue
            for issue in issues
            if issue.acknowledgement_required
            and issue.code not in project.acknowledged_warning_codes
        ]
        if unacknowledged:
            return ProjectStatus.CALCULATION_WARNING
        return ProjectStatus.READY_FOR_COPY

    def _empty_outcome(self, project: Project, issues: list[Issue]) -> CalculationOutcome:
        return CalculationOutcome(
            project_id=project.id,
            selected_forecast_run_id=project.selected_forecast_run_id,
            qnh_hpa=_manual_or_automatic(None, project.manual_qnh_hpa),
            fuel_plan=FuelPlan(total_usable_gal=project.total_usable_fuel_gal),
            issues=self._deduplicate_issues(issues),
            status=self._status(project, issues),
            policy_version=self.policies.version,
            performance_table_version=self.performance.manifest.source_revision,
        )
