# Data Provenance

性能CSVの正式な優先順位は、航空大学校の最新学生訓練実施要領、国土交通省承認版の
日本語飛行規程、英語版POHです。

各CSV行は出典ページを持ち、manifestは文書名、改訂日、照合先、ファイルSHA-256を
保持します。資料間の差異を検出した性能表は`VERIFIED`にせず、実行時に利用不能とします。
実行時にPDFは解析しません。

現行SR22 G6データは、P/N 13772-006 Reissue A（Revision A1のLOEP上、性能頁
5-30〜5-34はReissue A）から転記しました。上昇19行と巡航159行を別処理で再抽出し、
全行差分ゼロを確認しています。CSVのSHA-256、原典PDFのSHA-256、適用する
`climb_temperature_policy`は`data/performance/manifest.json`へ固定しています。
`VERIFIED`は数値転記とmanifest整合の状態であり、対象機への適用性、校内承認、または
Golden NAV2 LOGとのend-to-end一致を意味しません。

MSMの上空風・気温にはForecast Run、元URL、source hash、補間方法、格子・気圧面traceを
保存します。Colab操作プレビューのQNHには、AWC METAR取得URL、response SHA-256、
station ICAO、観測・取得・計画時刻、生METAR、観測経過時間を保存し、
`METAR観測QNH`と表示します。これは予報ではなく、公式飛行場気象資料の確認を代替
しません。手動上書き後も自動値、そのlabel、警告、根拠を削除しません。

SnapshotはProject revision、入力、手動値、性能表version、Policy version、気象要求と
結果、パッケージversion、警告を含む不変JSONです。
